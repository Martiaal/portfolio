package fr.but.info.objects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import java.util.Objects;

import com.github.forax.zen.PointerEvent.Location;

public class ResourceCard implements Card {
	
	private String topLeftCorner;
	private String topRightCorner;
	private String bottomLeftCorner;
	private String bottomRightCorner;
	
	private String kingdom;
	private int scoring;
	
	private int x = -CARD_WIDTH;
	private int y = -CARD_HEIGHT;
	private boolean isReversed = false;
	
	public ResourceCard(String[] argList) {
		this.topLeftCorner = argList[2];
		this.topRightCorner = argList[3];
		this.bottomLeftCorner = argList[4];
		this.bottomRightCorner = argList[5];
		
		this.kingdom = argList[7];
		
		// putting the scoring at 0 if it written "None" on the String
		this.scoring = argList[9].equals("None") ? 0 : Integer.valueOf(argList[9].split(":")[1]);
	}

	public void drawCard(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);

		// drawing the card
		graphics2D.setColor(Card.getColor(kingdom));
		graphics2D.fillRoundRect(x, y, CARD_WIDTH, CARD_HEIGHT, 20, 20);
		graphics2D.setColor(Color.BLACK);
		graphics2D.drawRoundRect(x, y, CARD_WIDTH, CARD_HEIGHT, 20, 20);
		
		if(isReversed) {
			drawReverseCard(graphics2D);
			return;
		}
		
		drawCardCorners(graphics2D);
		if(scoring > 0) {
			drawScoring(graphics2D);
		}
	}
	
	private void drawScoring(Graphics2D graphics2d) {
		Objects.requireNonNull(graphics2d);
		int contentX = x + Card.CARD_WIDTH/2 - Card.POINT_ZONE_SIZE/2;
		Card.drawRectInfo(String.valueOf(scoring), graphics2d, contentX, y);
	}
	
	private void drawCardCorners(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		
		drawCardCorner(topLeftCorner, graphics2D, x, y, CORNER_SIZE, CORNER_SIZE);
		drawCardCorner(topRightCorner, graphics2D, x + CARD_WIDTH - CORNER_SIZE, y, CORNER_SIZE, CORNER_SIZE);
		drawCardCorner(bottomLeftCorner, graphics2D, x, y + CARD_HEIGHT - CORNER_SIZE, CORNER_SIZE, CORNER_SIZE);
		drawCardCorner(bottomRightCorner, graphics2D, x + CARD_WIDTH - CORNER_SIZE, y + CARD_HEIGHT - CORNER_SIZE, CORNER_SIZE, CORNER_SIZE);
	}
	
	private void drawCardCorner(String corner, Graphics2D graphics2D, int x, int y, int width, int height) {
		Objects.requireNonNull(corner);
		Objects.requireNonNull(graphics2D);
		// not drawing if the corner is invisible
		if(corner.equals("Invisible")) {
			return;
		}
		graphics2D.setColor(CARD_CORNER_COLOR);
		graphics2D.fillRoundRect(x, y, width, height, 20, 20);
		// stop drawing if the corner is empty
		if (corner.equals("Empty")) {
			return;
		}
		// drawing the content of the corner
		drawCardCornerContent(corner, graphics2D, x, y);
	}
	
	private void drawCardCornerContent(String corner, Graphics2D graphics2D, int x, int y) {
		Objects.requireNonNull(corner);
		Objects.requireNonNull(graphics2D);
		// drawing the content of the corner
		var dividedCorner = corner.split(":");
		if(String.valueOf(dividedCorner[0]).equals("A")) {
			// drawing the letter if there is an artifact
			int contentX = (int) (x + CORNER_SIZE*0.3);
			int contentY = (int) (y + CORNER_SIZE*0.8);
			graphics2D.setColor(CARD_CORNER_TEXT_COLOR);
			graphics2D.drawString(String.valueOf(dividedCorner[1].charAt(0)), contentX, contentY);
		} else {
			// drawing a colored rectangle if it is a resource
			var resourceColor = Card.getColor(String.valueOf(dividedCorner[1]));
			int resX = x + (CORNER_SIZE - RESOURCE_SIZE)/2;
			int resY = y + (CORNER_SIZE - RESOURCE_SIZE)/2;
			graphics2D.setColor(resourceColor);
			graphics2D.fillRoundRect(resX, resY, RESOURCE_SIZE, RESOURCE_SIZE, 20, 20);
			}
	}

	@Override
	public boolean isPosInCard(Location mousePos) {
		Objects.requireNonNull(mousePos);
		// return true if the position of the mouse is inside the card
		return x < mousePos.x() && mousePos.x() <  x + CARD_WIDTH
				&& y < mousePos.y() && mousePos.y() < y + CARD_HEIGHT;
	}

	@Override
	public int x() {
		return x;
	}

	@Override
	public int y() {
		return y;
	}

	@Override
	public void setPos(int newX, int newY) {
		x = newX;
		y = newY;
	}

	private void drawReverseCard(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		
		drawMiddleResource(graphics2D);
		
		// draw its corners
		graphics2D.setColor(CARD_CORNER_COLOR);
		graphics2D.fillRoundRect(x, y, CORNER_SIZE, CORNER_SIZE, 20, 20);
		graphics2D.fillRoundRect(x + CARD_WIDTH - CORNER_SIZE, y, CORNER_SIZE, CORNER_SIZE, 20, 20);
		graphics2D.fillRoundRect(x, y + CARD_HEIGHT - CORNER_SIZE, CORNER_SIZE, CORNER_SIZE, 20, 20);
		graphics2D.fillRoundRect(x + CARD_WIDTH - CORNER_SIZE, y + CARD_HEIGHT - CORNER_SIZE, CORNER_SIZE, CORNER_SIZE, 20, 20);
	}
	
	private void drawMiddleResource(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		// drawing the frame of the resource in the middle
		graphics2D.setColor(CARD_CORNER_COLOR);
		int middleX = x + CARD_WIDTH/2 - CORNER_SIZE/2;
		int middleY = y + CARD_HEIGHT/2 - CORNER_SIZE/2;
		graphics2D.fillRoundRect(middleX, middleY, CORNER_SIZE, CORNER_SIZE, 20, 20);
		graphics2D.setColor(CARD_BORDER_COLOR);
		graphics2D.drawRoundRect(middleX, middleY, CORNER_SIZE, CORNER_SIZE, 20, 20);
		// drawing the resource in the middle
		graphics2D.setColor(Card.getColor(kingdom));
		int resX = middleX + CORNER_SIZE/2 - RESOURCE_SIZE/2;
		int resY = middleY + CORNER_SIZE/2 - RESOURCE_SIZE/2;
		graphics2D.fillRoundRect(resX, resY, RESOURCE_SIZE, RESOURCE_SIZE, 20, 20);
	}

	@Override
	public List<Corner> getAllCorners(){
		// returns a list of every corners. If the card is reversed, returns a list of empty corners
		if(isReversed) {
			return List.of(new Corner(x, y, "Empty"), new Corner(x + CARD_WIDTH - CORNER_SIZE, y, "Empty"), 
					new Corner(x, y + CARD_HEIGHT - CORNER_SIZE, "Empty"), new Corner(x + CARD_WIDTH - CORNER_SIZE, y + CARD_HEIGHT - CORNER_SIZE, "Empty"));
		}
		return List.of(new Corner(x, y, topLeftCorner), new Corner(x + CARD_WIDTH - CORNER_SIZE, y, topRightCorner), 
				new Corner(x, y + CARD_HEIGHT - CORNER_SIZE, bottomLeftCorner), new Corner(x + CARD_WIDTH - CORNER_SIZE, y + CARD_HEIGHT - CORNER_SIZE, bottomRightCorner));
	}
	
	@Override
	public void replace(int replaceType, Card card) {
		Objects.requireNonNull(card);
		// places the map correctly with respect to the one passed in parameter
		int left = card.x() - CARD_WIDTH + CORNER_SIZE;
		int top = card.y() - CARD_HEIGHT + CORNER_SIZE;
		int right = card.x() + CARD_WIDTH - CORNER_SIZE;
		int bottom = card.y() + CARD_HEIGHT - CORNER_SIZE;
		switch(replaceType) {
		case 1:
			setPos(left, top);
			break;
		case 2:
			setPos(right, top);
			break;
		case 3:
			setPos(left, bottom);
			break;
		case 4:
			setPos(right, bottom);
			break;
		default: return;
		}
	}
	
	@Override
	public void setPos(double newX, double newY) {
		x = (int) newX;
		y = (int) newY;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(topLeftCorner, topRightCorner, bottomLeftCorner, bottomRightCorner, kingdom, scoring);
	}
	
	@Override
	public boolean equals(Object o) {
		return o instanceof ResourceCard other
				&& topLeftCorner.equals(other.topLeftCorner) && topRightCorner.equals(other.topRightCorner) && bottomLeftCorner.equals(other.bottomLeftCorner)
				&& bottomRightCorner.equals(other.bottomRightCorner) && kingdom.equals(other.kingdom) && scoring == other.scoring;
	}

	@Override
	public void score(Player player, int cornersCovered) {
		Objects.requireNonNull(player);
		if(isReversed) {
			return;
		}
		player.addScore(scoring);
	}
	
	@Override
	public void setReverse(boolean value) {
		isReversed = value;
	}
	
	@Override
	public boolean isReversed() {
		return isReversed;
	}

	@Override
	public String getKingdom() {
		return kingdom;
	}
	
}
