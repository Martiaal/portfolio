package fr.but.info.game;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.github.forax.zen.ApplicationContext;
import com.github.forax.zen.Event;
import com.github.forax.zen.KeyboardEvent;
import com.github.forax.zen.PointerEvent;
import com.github.forax.zen.PointerEvent.Location;

import fr.but.info.objects.Card;

public class EventManager {
	private final ApplicationContext context;
	private final GameManager gameManager;
	private final ScreenManager screenManager;
	// keyReleased is useful in the case we want to reverse a card by pressing 'r'. It allows to turn the card once even if while holding the button
	boolean keyReleased = true;
	
	public EventManager(ApplicationContext context, GameManager gameManager, ScreenManager screenManager) {
		Objects.requireNonNull(context);
		Objects.requireNonNull(gameManager);
		Objects.requireNonNull(screenManager);
		this.context = context;
		this.gameManager = gameManager;
		this.screenManager = screenManager;
	}
	
	public void getEventContext() throws IOException {
		// retrieving the event
		Event event = context.pollOrWaitEvent(100);
		// doing an action depending on the event type
		if(event != null) {
			switch (event) {
			case PointerEvent pointerEvent -> {
				pointerEventAction(pointerEvent);
				return;
			}
			case KeyboardEvent keyboardEvent -> {
				keyboardEventAction(keyboardEvent);
				return;
			}
			default -> throw new IllegalArgumentException("Unexpected value: " + event);
			}
		}
		else {
			// if no event is detected, it means we are not pressing any keys
			keyReleased = true;
		}
	}
	
	private void keyboardEventAction(KeyboardEvent keyboardEvent) throws IOException {
		Objects.requireNonNull(keyboardEvent);
		// the keyboard event action depends on the current state of the game
		switch(gameManager.getGameState()) {
		case "menu" : keyboardEventMenuAction(keyboardEvent); break;
		case "play" : keyboardEventGameAction(keyboardEvent); break;
		case "win" : gameManager.changeGameState("menu"); gameManager.init_game(); break;
		case "starter" : chooseStarterCardAction(keyboardEvent); break;
		case "objective" : keyboardEventMenuAction(keyboardEvent); break;
		}
	}

	private void pointerEventAction(PointerEvent pointerEvent) {
		Objects.requireNonNull(pointerEvent);
		// the pointer event action depends on the current state of the game
		switch(gameManager.getGameState()) {
		case "menu" : pointerEventMenuAction(pointerEvent); break;
		case "play" : pointerEventGameAction(pointerEvent); break;
		case "objective" : pointerEventObjectiveAction(pointerEvent); break;
		}
	}

	private void pointerEventObjectiveAction(PointerEvent pointerEvent) {
		Objects.requireNonNull(pointerEvent);
		// getting the position of the mouse
		var mousePos = pointerEvent.location();
		// checking if the player has clicked on an objective card
		if (pointerEvent.action() == PointerEvent.Action.POINTER_DOWN) {
			checkObjectiveMouseClick(mousePos);
			return;
		}
	}

	private void checkObjectiveMouseClick(Location mousePos) {
		Objects.requireNonNull(mousePos);
		// checking if the player has clicked on the first objective card
		var obj1 = gameManager.getFirstObjective();
		if(obj1.isPosInCard(mousePos)) {
			gameManager.selectObjective(0);
			return;
		}
		// checking if the player has clicked on the second objective card
		var obj2 = gameManager.getSecondObjective();
		if(obj2.isPosInCard(mousePos)) {
			gameManager.selectObjective(1);
		}
	}

	private void chooseStarterCardAction(KeyboardEvent keyboardEvent) {
		Objects.requireNonNull(keyboardEvent);
		// exiting the application when "Escape" is pressed
		if (keyboardEvent.key() == KeyboardEvent.Key.ESCAPE) {
			context.dispose();
			System.exit(0);
			return;
		}
		// if we are holding a key, we can't go to the next part. Without this, when a player press a button, it is almost immediately pressed
		// for the other players
		if(!keyReleased) {
			return;
		}
		// putting the key released on false as the user just pressed a key
		keyReleased = false;
		// if the player has not pressed r, we don't reverse the card. At this state of the program, the starter card is always reversed,
		// so we don't have to reverse it
		if (keyboardEvent.key() != KeyboardEvent.Key.R) gameManager.getStarterCard().setReverse(false);
		// adding the starter card to the player who had to select it
		gameManager.addStarterCard();
	}

	private void keyboardEventMenuAction(KeyboardEvent keyboardEvent) {
		Objects.requireNonNull(keyboardEvent);
		// exiting the application when "Escape" is pressed
		if (keyboardEvent.key() == KeyboardEvent.Key.ESCAPE) {
			context.dispose();
			System.exit(0);
			return;
		}
	}

	public void pointerEventGameAction(PointerEvent pointerEvent) {
		Objects.requireNonNull(pointerEvent);
		// getting the position of the mouse
		var mousePos = pointerEvent.location();
		
		if (pointerEvent.action() == PointerEvent.Action.POINTER_DOWN) {
			// checking if the player has clicked on a card, only if the currently displayed player is the same as the player
			// who must play
			if(gameManager.getDisplayPLayerIndex() == gameManager.getActualPlayerIndex()) {
				checkMouseClick(mousePos);
			}
			// checking if the player has clicked on the player's menu
			checkClickOnPlayer(mousePos);
            return;
          }
		
		if (pointerEvent.action() == PointerEvent.Action.POINTER_UP) {
			// when the player is releasing the mouse while holding a card, we release the card as well
			if(gameManager.hasActiveCard()) {
				gameManager.removeActiveCard();
			}
		}
		
		if (pointerEvent.action() == PointerEvent.Action.POINTER_MOVE) {
			// when the player is moving the mouse while holding a card, we move the card as well
			if(gameManager.hasActiveCard()) {
				gameManager.moveActiveCard(mousePos);
			}
		}
	}
	
	private void checkClickOnPlayer(Location mousePos) {
		Objects.requireNonNull(mousePos);
		// getting play area and mouse coordinates
		var x = gameManager.getGameAreaX("playArea");
		var y = gameManager.getGameAreaY("playArea");
		var xMouse = mousePos.x();
		var yMouse = mousePos.y();
		// getting player's section width and height
		var width = Card.CARD_WIDTH;
		var height = Card.CORNER_SIZE;
		// stopping the method if the player has clicked on the left or on the right of sections
		if(xMouse < x || xMouse > x + width) return;
		// getting the index of the player we clicked on
		var playerNum = (int) ((yMouse-y)/height);
		// if the index is valid, we change the player to display
		if(playerNum >= 0 && playerNum <= gameManager.getMaxPlayerIndex()) {
			gameManager.setDisplayPlayerIndex(playerNum);
		}
	}

	public void pointerEventMenuAction(PointerEvent pointerEvent) {
		Objects.requireNonNull(pointerEvent);
		// getting the position of the mouse
		var mousePos = pointerEvent.location();
		// checking if the player has clicked on a menu's button
		if (pointerEvent.action() == PointerEvent.Action.POINTER_DOWN) {
			checkMenuButtonMouseClick(mousePos);
            return;
          }
	}
	
	private void checkMenuButtonMouseClick(Location mousePos) {
		Objects.requireNonNull(mousePos);
		for(var button : screenManager.getMenuButtons()) {
			if(button.isPosInButton(mousePos)) {
				// launch the game with as many players as indicated on the button
				switch(button.label()) {
				case "1 player" : gameManager.changeGameState("starter"); gameManager.setMaxPlayerIndex(0); break;
				case "2 players" : gameManager.changeGameState("starter"); gameManager.setMaxPlayerIndex(1); break;
				case "3 players" : gameManager.changeGameState("starter"); gameManager.setMaxPlayerIndex(2); break;
				case "4 players" : gameManager.changeGameState("starter"); gameManager.setMaxPlayerIndex(3); break;
				}
			}
		}
	}

	private void checkMouseClick(Location mousePos) {
		Objects.requireNonNull(mousePos);
		// retrieving needed cards
		var playerState = gameManager.getPlayerState();
		var cardList = getCardList(playerState);
		// checking if the player has clicked on a card
		for(var card : cardList) {
			if(card.isPosInCard(mousePos)) {
				// playing the cards if the player has to play, else picking it
				if(playerState.equals("play")) {
					playCardAction(card, mousePos);
					return;
				}
				gameManager.pickCard(card);
				return;
			}
		}
	}

	private void playCardAction(Card card, Location mousePos) {
		Objects.requireNonNull(card);
		Objects.requireNonNull(mousePos);
		// making the card active
		gameManager.setActiveCard(card, mousePos);
	}

	private List<Card> getCardList(String playerState) {
		Objects.requireNonNull(playerState);
		// returns the hand of the player or the deck's available cards
		if(playerState.equals("play")) {
			return gameManager.getActivePlayerHand();
		}
		var deckList = new ArrayList<Card>();
		deckList.addAll(gameManager.getGoldDeck());
		deckList.addAll(gameManager.getResourceDeck());
		return deckList;
	}

	public void keyboardEventGameAction(KeyboardEvent keyboardEvent) {
		Objects.requireNonNull(keyboardEvent);
		// exiting the application when "Escape" is pressed
		if (keyboardEvent.key() == KeyboardEvent.Key.ESCAPE) {
			context.dispose();
			System.exit(0);
			return;
		}
		// reverse the card if we are not holding the key
		if(keyboardEvent.key() == KeyboardEvent.Key.R && gameManager.hasActiveCard() && keyReleased) {
			gameManager.changeActiveCardReversed();
			keyReleased = false;
		}
		// moving every played cards of the currently displayed player thanks to arrows keys
		if(keyboardEvent.key() == KeyboardEvent.Key.LEFT) {
			gameManager.changeDisplayedPlayedCardPos(1, 0);
		}
		if(keyboardEvent.key() == KeyboardEvent.Key.RIGHT) {
			gameManager.changeDisplayedPlayedCardPos(-1, 0);
		}
		if(keyboardEvent.key() == KeyboardEvent.Key.UP) {
			gameManager.changeDisplayedPlayedCardPos(0, 1);
		}
		if(keyboardEvent.key() == KeyboardEvent.Key.DOWN) {
			gameManager.changeDisplayedPlayedCardPos(0, -1);
		}
	}
}
