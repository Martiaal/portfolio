package fr.but.info.objects;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class Player implements Comparable<Player> {
	private final List<Card> hand = new ArrayList<Card>();
	private final List<Card> playedCards = new ArrayList<Card>();
	private final HashMap<String, Integer> resources = createNewResourcesMap();
	private ObjectiveCard objective;
	private int score = 0;
	private int formerScore = 0;
	private final Color color;
	
	public Player(Color c) {
		Objects.requireNonNull(c);
		color = c;
	}

	public void addCard(Card card) {
		Objects.requireNonNull(card);
		hand.add(card);
	}
	
	public void addResource(String kingdom) {
		Objects.requireNonNull(kingdom);
		resources.put(kingdom, resources.get(kingdom) + 1);
	}
	
	public void addScore(int amount) {
		score += amount;
	}
	
	public int cardsAmount() {
		return hand.size();
	}
	
	public boolean checkResources(Map<String, Integer> costMap) {
		Objects.requireNonNull(costMap);
		// returns true if the player has at least as many resources as costMap
		for(var resource : costMap.keySet()) {
			if(resources.get(resource) < costMap.get(resource)) {
				System.out.println(resources);
				return false;
			}
		}
		return true;
	}
	
	public Color getColor() {
		return color;
	}
	
	public int getFormerScore() {
		return formerScore;
	}
	
	public List<Card> getHand(){
		return List.copyOf(hand);
	}
	
	public ObjectiveCard getObjective() {
		return objective;
	}
	
	public List<Card> getPlayedCards() {
		return List.copyOf(playedCards);
	}
	
	public int getResource(String resource) {
		Objects.requireNonNull(resource);
		return resources.getOrDefault(resource, 0);
	}
	
	public HashMap<String, Integer> getResources() {
		return resources;
	}
	
	public int getScore() {
		return score;
	}
	
	static private HashMap<String, Integer> createNewResourcesMap() {
		// create a map with every resources and artifacts as keys
		var map = new HashMap<String, Integer>();
		for(var kingdom : List.of("Animal", "Fungi", "Insect", "Plant", "Q", "M", "I")) {
			map.put(kingdom, 0);
		}
		return map;
	}
	
	public boolean hasPlayedCards() {
		// return true if the player has played at least one card
		return playedCards.size() != 0;
	}
	
	public boolean playCard(Card card) {
		Objects.requireNonNull(card);
		// return false if the player has played a gold card without having required resources
		if(card instanceof GoldCard && !card.isReversed()) {
			var goldCard = (GoldCard) card;
			if(! checkResources(goldCard.getCostMap())) {
				return false;
			}
		}
		// removing the card from the hand and adding it to the played cards
		playedCards.add(card);
		hand.remove(card);
		if(card.isReversed()) {
			return true;
		}
		// adding resources and artifacts of the cards to the player
		for(var corner : card.getAllCorners()) {
			var content = corner.content().split(":");
			if(String.valueOf(content[0]).equals("R")) {
				addResource(String.valueOf(content[1]));
				continue;
			}
			if(String.valueOf(content[0]).equals("A")) {
				addResource(String.valueOf(content[1].charAt(0)));
			}
		}
		return true;
	}
	
	public void removeResource(String kingdom, int amount) {
		Objects.requireNonNull(kingdom);
		resources.put(kingdom, resources.get(kingdom) - amount);
	}
	
	public void setObjective(ObjectiveCard obj) {
		Objects.requireNonNull(obj);
		objective = obj;
	}
	
	public void setFormerScore(int newScore) {
		formerScore = newScore;
	}

	public void setScore(int newScore) {
		score = newScore;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(color);
	}
	
	@Override
	public boolean equals(Object o) {
		return o instanceof Player other
				&& color.equals(other.color);
	}

	@Override
	public int compareTo(Player o) {
		int comparison = Integer.valueOf(score).compareTo(o.score);
		if(comparison == 1) {
			return -1;
		}
		return 1;
	}
}
