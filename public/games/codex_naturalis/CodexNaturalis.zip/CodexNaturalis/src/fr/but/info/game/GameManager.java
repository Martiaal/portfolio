package fr.but.info.game;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Objects;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import com.github.forax.zen.Application;
import com.github.forax.zen.PointerEvent.Location;

import fr.but.info.objects.Card;
import fr.but.info.objects.GameArea;
import fr.but.info.objects.GoldCard;
import fr.but.info.objects.ObjectiveCard;
import fr.but.info.objects.Player;
import fr.but.info.objects.ResourceCard;
import fr.but.info.objects.StarterCard;

public class GameManager {
	
	private final List<ResourceCard> resourceDeck = new ArrayList<ResourceCard>();
	private final List<GoldCard> goldDeck = new ArrayList<GoldCard>();
	private final List<StarterCard> starterDeck = new ArrayList<StarterCard>();
	private final List<ObjectiveCard> objectiveDeck = new ArrayList<ObjectiveCard>();
	private List<Player> playersList = init_player_list();
	private final Map<String, GameArea> areasMap = new HashMap<String, GameArea>();
	
	private Card activeCard = null;
	private Player activePlayer = null;
	private int xOffset = 0;
	private int yOffset = 0;
	private String playerState = "play";
	private String gameState = "menu";
	private int starterCardNum;
	private int objectiveCardNum;
	private int formerScore;
	private int maxPlayerIndex;
	private int actualPlayerIndex;
	private int displayPlayerIndex;
	private int round;
	
	private final Color bgColor = new Color(36, 29, 80);
	
	public void launch() throws IOException {
		
		// takes all cards from the decks.txt file
		init_game();
		
		// running the application
		Application.run(bgColor, context -> {
			var screenManager = new ScreenManager(context, this);
			try {
				screenManager.getContext();
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}
	
	private List<Player> init_player_list() {
		// returns a list of 4 players
		return List.of(new Player(Color.YELLOW), new Player(Color.PINK), new Player(Color.CYAN), new Player(Color.GREEN));
	}

	public void init_game() throws IOException {
		// initializing many variables for the game
		starterCardNum = 0;
		objectiveCardNum = 0;
		formerScore = 0;
		maxPlayerIndex = 0;
		actualPlayerIndex = 0;
		displayPlayerIndex = 0;
		round = 1;
		resourceDeck.clear();
		goldDeck.clear();
		starterDeck.clear();
		objectiveDeck.clear();
		playersList = init_player_list();
		retrieveAllCards();
	}
	
	public List<Player> realPlayers() {
		// returns the list of currently playing players
		return playersList.subList(0, maxPlayerIndex+1);
	}
	
	private void addObjectivePoints() {
		// adding every objective points to every players
		for(var player : realPlayers()) {
			player.getObjective().score(player, 0);
			getFirstObjective().score(player, 0);
			getSecondObjective().score(player, 0);
		}
	}

	public void addStarterCard() {
		// getting the starter card and the player who selected it
		var sc = starterDeck.get(starterCardNum);
		var player = playersList.get(starterCardNum);
		// playing the starter card
		putCardInMiddle(sc);
		player.playCard(sc);
		// retrieving its middle resources (corner's resources are retrieved in player.playCard(sc))
		for(var res : sc.getResources()) {
			player.addResource(res);
		}
		// allowing the next player to select its card
		starterCardNum++;
		if(starterCardNum > maxPlayerIndex) {
			// if every player selected its card, we pass to the selection of objective cards
			changeGameState("objective");
		}
	}
	
	public void changeActiveCardReversed() {
		// reverse the currently held card
		activeCard.setReverse(!activeCard.isReversed());
	}
	
	public void changeGameState(String state) {
		Objects.requireNonNull(state);
		gameState = state;
	}
	
	public void changeDisplayedPlayedCardPos(int i, int j) {
		// moving the displayed played cards from offset
		// i and j can take 1, -1 and 0 as value. their value is depending on the arrow key pressed.
		int offset = 15;
		for(var card : playersList.get(displayPlayerIndex).getPlayedCards()) {
			card.setPos(card.x() + i*offset, card.y() + j*offset);
		}
	}
	
	private void changePlayer() {
		// going to the next player
		actualPlayerIndex++;
		// if the last player has play, we come back to the first player and increment the round
		if(actualPlayerIndex > maxPlayerIndex) {
			actualPlayerIndex = 0;
			round++;
		}
		// actualizing active player and putting displaying him
		displayPlayerIndex = actualPlayerIndex;
		activePlayer = playersList.get(actualPlayerIndex);
		System.out.println("Player : " + (actualPlayerIndex + 1));
		System.out.println(activePlayer.getResources());
	}
	
	public void changePlayerState() {
		// change the state of the player from "play" to "pick" and vice versa
		if(playerState.equals("play")) {
			playerState = "pick";
			return;
		}
		playerState = "play";
	}
	
	private void distributeStartingCards() {
		// adding cards to each player and actualizing their hand position
		for(var player : realPlayers()) {
			player.addCard(goldDeck.removeFirst());
			player.addCard(resourceDeck.removeFirst());
			player.addCard(resourceDeck.removeFirst());
			setHandPos(player);
		}
	}
	
	public Player getActivePlayer() {
		return activePlayer;
	}
	
	public List<Card> getActivePlayerHand() {
		return activePlayer.getHand();
	}
	
	public List<Card> getActivePlayerPlayedCards() {
		return activePlayer.getPlayedCards();
	}
	
	public Color getBgColor() {
		return bgColor;
	}
	
	public TreeMap<Player, Integer> getRanking() {
		// return a sorted ranking of every players with player as key and their score as value
		var rankings = new TreeMap<Player, Integer>();
		for(var player : realPlayers()) {
			rankings.put(player, player.getScore());
		}
		return rankings;
	}
	
	public int getDisplayPLayerIndex() {
		return displayPlayerIndex;
	}
	
	public ObjectiveCard getFirstObjective() {
		return objectiveDeck.get(objectiveCardNum);
	}
	
	public ObjectiveCard getSecondObjective() {
		return objectiveDeck.get(objectiveCardNum+1);
	}
	
	public GameArea getGameArea(String label) {
		Objects.requireNonNull(label);
		return areasMap.get(label);
	}
	
	public List<GameArea> getGameAreas() {
		return List.copyOf(areasMap.values());
	}

	public int getGameAreaX(String label) {
		Objects.requireNonNull(label);
		return getGameArea(label).x();
	}
	
	public int getGameAreaY(String label) {
		Objects.requireNonNull(label);
		return getGameArea(label).y();
	}
	
	public String getGameState() {
		return gameState;
	}
	
	public List<GoldCard> getGoldDeck(){
		// retrieving the three (or less) available cards of the deck
		return List.copyOf(goldDeck.subList(0, goldDeck.size() > 2 ? 3 : goldDeck.size()));
	}
	
	public int getPlayerIndex(Player player) {
		// returns the index of player
		return playersList.indexOf(player);
	}
	
	public String getPlayerState() {
		// returning "play" or "pick" depending on the action the player must do
		return playerState;
	}
	
	public List<ResourceCard> getResourceDeck(){
		// retrieving the three (or less) available cards of the deck
		return List.copyOf(resourceDeck.subList(0, resourceDeck.size() > 2 ? 3 : resourceDeck.size()));
	}
	
	public int getRound() {
		return round;
	}
	
	public StarterCard getStarterCard() {
		// returns the starter card that must currently be choose
		return starterDeck.get(starterCardNum);
	}
	
	public int getStarterCardNum() {
		return starterCardNum;
	}
	
	public int getObjectiveCardNum() {
		return objectiveCardNum;
	}
	
	public boolean hasActiveCard() {
		// return true if the player is holding a card
		return activeCard != null;
	}
	
	public void moveActiveCard(Location mousePos) {
		Objects.requireNonNull(mousePos);
		// actualizing the position of the active card, following the mouse cursor
		activeCard.setPos(mousePos.x() - xOffset, mousePos.y() - yOffset);
	}
	
	public void pickCard(Card card) {
		Objects.requireNonNull(card);
		// adding the card to the player and removing it from the deck
		activePlayer.addCard(card);
		goldDeck.remove(card);
		resourceDeck.remove(card);
		card.setReverse(false);
		// actualize the position of the hand and of the deck
		setHandPos(activePlayer);
		setDeckPos();
		// actualize the player
		changePlayerState();
		changePlayer();
		// ending the game if there is no pick left
		if(resourceDeck.isEmpty() && goldDeck.isEmpty()) {
			addObjectivePoints();
			setFormerScores();
			changeGameState("win");
		}
	}
	
	public void putCardInMiddle(Card card) {
		Objects.requireNonNull(card);
		// if the player has not played any cards, the card is put in the middle of the play area
		var playArea = getGameArea("playArea");
		int x = playArea.x() + playArea.width()/2 - Card.CARD_WIDTH/2;
		int y = playArea.y() + playArea.height()/2 - Card.CARD_HEIGHT/2;
		card.setPos(x, y);
	}
	
	public void removeActiveCard() {
		var resToRemove = canPlaceActiveCard();
		// if the card can be placed, we place it
		if(resToRemove != null) {
			if(activePlayer.playCard(activeCard)) {
				formerScore = 0;
				changePlayerState();
				if(activeCard.isReversed()) {
					activePlayer.addResource(activeCard.getKingdom());
				}
				// removing the resources covered
				removeResources(resToRemove);
			} else {
				activePlayer.setScore(formerScore);
				formerScore = 0;
			}
			if(activePlayer.getScore() > 20) {
				endGame();
			}
		}
		// removing the active card information
		activeCard = null;
		xOffset = 0;
		yOffset = 0;
		// actualizing the position of the hand
		setHandPos(activePlayer);
	}

	private void removeResources(Map<String, Integer> resToRemove) {
		// removing each resources from resToRemove to the active player
		for(var kingdom : resToRemove.keySet()) {
			activePlayer.removeResource(kingdom, resToRemove.get(kingdom));
		}
	}

	private void endGame() {
		// keeping scores before objective points, then adding objective points, finally go to the winning screen
		setFormerScores();
		addObjectivePoints();
		changeGameState("win");
	}

	private void retrieveAllCards() throws IOException {
		// Utilisez ClassLoader pour accéder à la ressource à l'intérieur du JAR
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("fr/but/info/ressources/deck.txt");
             BufferedReader deckReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {

            if (inputStream == null) {
                throw new RuntimeException("Ressource non trouvée : fr/but/info/ressources/deck.txt");
            }

            // Création de chaque carte
            String line;
            while ((line = deckReader.readLine()) != null) {
                Card.convertStringToCard(line, resourceDeck, goldDeck, starterDeck, objectiveDeck);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Erreur lors de la lecture du fichier deck.txt", e);
        }
		// shuffling each decks
		Collections.shuffle(goldDeck);
		Collections.shuffle(resourceDeck);
		Collections.shuffle(starterDeck);
		Collections.shuffle(objectiveDeck);
	}
	
	public void retrieveAllGameAreas(int width, int height) throws IOException {
		// Utilisez ClassLoader pour accéder à la ressource à l'intérieur du JAR
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("fr/but/info/ressources/gameAreas.txt");
             BufferedReader gameAreaReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {

            if (inputStream == null) {
                throw new RuntimeException("Ressource non trouvée : fr/but/info/ressources/gameAreas.txt");
            }

            // Création d'un objet GameArea pour chaque ligne du fichier
            String line;
            while ((line = gameAreaReader.readLine()) != null) {
                GameArea.addGameArea(areasMap, line, width, height);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Erreur lors de la lecture du fichier gameAreas.txt", e);
        }
	}
	
	public void selectObjective(int num) {
		// adding the selected objective card to the player that selected it
		playersList.get(objectiveCardNum/2).setObjective(objectiveDeck.get(objectiveCardNum + num));
		// actualizing the objective card index to select
		objectiveCardNum += 2;
		if(objectiveCardNum/2 > maxPlayerIndex) {
			// if every player have selected his objective card, we can start the game
			changeGameState("play");
			playerState = "play";
			distributeStartingCards();
			activePlayer = playersList.getFirst();
			// actualizing the deck position
			setDeckPos();
			// actualizing each objective card position
			for(var player : realPlayers()) setObjectivePos(player);
		}
	}
	
	public void setActiveCard(Card card, Location mousePos) {
		Objects.requireNonNull(card);
		Objects.requireNonNull(mousePos);
		// putting the card active and keep the offset between the card and the click position
		activeCard = card;
		xOffset = mousePos.x() - card.x();
		yOffset = mousePos.y() - card.y();
	}
	
	public void setDeckPos() {
		var gameArea = getGameArea("pickArea");
		// variable for the positioning of the cards from the deck
		double xSpacement = (gameArea.width() - Card.CARD_WIDTH*2) / 3;
		double ySpacement = (gameArea.height() - Card.CARD_HEIGHT*3) / 4;
		
		double xCard = gameArea.x() + xSpacement;
		double yCard = gameArea.y() + ySpacement;
		
		double x2 = xCard + Card.CARD_WIDTH + xSpacement;
		
		boolean reverse = true;
		// positioning each available card of the deck
		for(int i = 2; i >= 0; i--) {
			if(resourceDeck.size() > i) {
				resourceDeck.get(i).setPos(xCard, yCard);
				resourceDeck.get(i).setReverse(reverse);
			}
			if(goldDeck.size() > i) {
				goldDeck.get(i).setPos(x2, yCard);
				goldDeck.get(i).setReverse(reverse);
			}
			// reversing only the first card of each deck, so we have to set reverse on false
			reverse = false;
			yCard += Card.CARD_HEIGHT + ySpacement;
		}
	}
	
	public void setDisplayPlayerIndex(int i) {
		displayPlayerIndex = i;
	}
	
	private void setFormerScores() {
		// player's formerScore will be useful for the winning screen, to display scores before and after adding objective points
		for(var player : realPlayers()) {
			player.setFormerScore(player.getScore());
		}
	}
	
	public void setHandPos(Player player) {
		var gameArea = getGameArea("handArea");
		// variables for the positioning of the hands cards
		int cardsAmount = player.cardsAmount();
		double xSpacement = (gameArea.width() - Card.CARD_WIDTH*cardsAmount) / (cardsAmount+1);
		double ySpacement = (gameArea.height() - Card.CARD_HEIGHT) / 2;
		
		double xCard = gameArea.x() + xSpacement;
		double yCard = gameArea.y() + ySpacement;
		// positioning of the hands cards
		for(var card : player.getHand()) {
			card.setPos(xCard, yCard);
			xCard += xSpacement + Card.CARD_WIDTH;
		}
	}
	
	public void setObjectivePos(Player player) {
		var gameArea = getGameArea("objectiveArea");
		// variables for the positioning of the objective cards
		double xSpacement = (gameArea.width() - Card.CARD_WIDTH*3) / 4;
		double ySpacement = (gameArea.height() - Card.CARD_HEIGHT) / 2;
		
		double xCard = gameArea.x() + xSpacement;
		double yCard = gameArea.y() + ySpacement;
		// positioning of the objective cards
		player.getObjective().setPos(xCard, yCard);
		xCard += xSpacement + Card.CARD_WIDTH;
		
		getFirstObjective().setPos(xCard, yCard);
		xCard += xSpacement + Card.CARD_WIDTH;
		
		getSecondObjective().setPos(xCard, yCard);
	}
	
	private Map<String, Integer> canPlaceActiveCard() {
	    // get all the corners of the held card
	    var corners = activeCard.getAllCorners();
	    // initializing many variables for the placement checking
	    boolean hasOneValid = false;
	    int replaceType = 0;
	    int cornersCovered = 0;
	    Card replaceCard = null;
	    var resourcesToRemove = new HashMap<String, Integer>();
	    // browse all cards played by the active player
	    for (var card : activePlayer.getPlayedCards()) {
	        boolean hasOneCollider = false;
	        // get every corner of the held card
	        for (var activeCorner : corners) {
	            int i = 0;
	            // get every corner of the currently studied card
	            for (var corner : card.getAllCorners()) {
	                i++;
	                // checking if there is a collision between the studied active corner and the studied corner
	                if (activeCorner.collides(corner)) {
	                    // if a corner from the held card was already in collision with a corner from the studied card or is in collision
	                	// with an invisible corner, we return null
	                    if (hasOneCollider || corner.content().equals("Invisible")) {
	                        return null;
	                    }
	                    // else, adding a corner covered (for the scoring of some gold cards), setting the replaceType (to know in which corner
	                    // we will replace the held card) and the replace card (the card on which the replacement of the held card will be based)
	                    cornersCovered++;
	                    replaceType = i;
	                    replaceCard = card;
	                    hasOneCollider = true;
	                    // add the resource to be removed
	                    Card.tryAddResource(resourcesToRemove, corner);
	                }
	            }
	        }
	        // if at one corner has collided, the card is valid for placing
	        if (hasOneCollider) {
	            hasOneValid = true;
	        }
	    }
	    // if the placing is valid, we place correctly the card and update the score
	    // we keep the former score in case this is a gold card we can't place, as we have not verified it yet
	    if (hasOneValid) {
	        activeCard.replace(replaceType, replaceCard);
	        formerScore = activePlayer.getScore();
	        activeCard.score(activePlayer, cornersCovered);
	        return resourcesToRemove;
	    }
	    // if no valid card was found, return null
	    return null;
	}

	public void setMaxPlayerIndex(int i) {
		maxPlayerIndex = i;
	}

	public int getActualPlayerIndex() {
		return actualPlayerIndex;
	}

	public List<Player> getPlayers() {
		return playersList;
	}

	public List<Player> getPlayersWithScore(int score) {
		var players = new ArrayList<Player>();
		// adding every player with the score asked in the list players
		for(var player : realPlayers()) {
			if(player.getScore() == score) {
				players.add(player);
			}
		}
		return players;
	}

	public List<Card> getDisplayPlayerPlayedCards() {
		return playersList.get(displayPlayerIndex).getPlayedCards();
	}

	public List<Card> getDisplayPlayerHand() {
		return playersList.get(displayPlayerIndex).getHand();
	}

	public Player getDisplayPlayer() {
		return playersList.get(displayPlayerIndex);
	}

	public int getMaxPlayerIndex() {
		return maxPlayerIndex;
	}

}
