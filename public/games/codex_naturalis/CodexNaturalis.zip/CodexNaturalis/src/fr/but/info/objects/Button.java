package fr.but.info.objects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Objects;

import com.github.forax.zen.PointerEvent.Location;

public record Button(String label, int x, int y, int width, int height) {
	
	static final Color BUTTON_COLOR = Color.GRAY;
	static final Color BUTTON_BORDER_COLOR = Color.DARK_GRAY;
	
	public Button {
		Objects.requireNonNull(label);
	}
	
	public boolean isPosInButton(Location mousePos) {
		Objects.requireNonNull(mousePos);
		return x < mousePos.x() && mousePos.x() <  x + width
				&& y < mousePos.y() && mousePos.y() < y + height;
	}
	
	public void drawButton(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);

		// drawing the card
		graphics2D.setColor(BUTTON_COLOR);
		graphics2D.fillRoundRect(x, y, width, height, 20, 20);
		graphics2D.setColor(BUTTON_BORDER_COLOR);
		graphics2D.drawRoundRect(x, y, width, height, 20, 20);
		graphics2D.setColor(Color.BLACK);
		graphics2D.drawString(label, (int) (x+width*0.1), (int) (y+height*0.73));
	}
}
