package fr.but.info.objects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.github.forax.zen.PointerEvent.Location;

public class StarterCard implements Card {
	
	private String topLeftCorner;
	private String topRightCorner;
	private String bottomLeftCorner;
	private String bottomRightCorner;
	
	private String reverseTopLeftCorner;
	private String reverseTopRightCorner;
	private String reverseBottomLeftCorner;
	private String reverseBottomRightCorner;
	
	private final List<String> resourceList = new ArrayList<String>();
	
	private int x = -CARD_WIDTH;
	private int y = -CARD_HEIGHT;
	private boolean isReversed = false;
	
	public StarterCard(String[] argList) {
		this.topLeftCorner = argList[2];
		this.topRightCorner = argList[3];
		this.bottomLeftCorner = argList[4];
		this.bottomRightCorner = argList[5];
		this.reverseTopLeftCorner = argList[7];
		this.reverseTopRightCorner = argList[8];
		this.reverseBottomLeftCorner = argList[9];
		this.reverseBottomRightCorner = argList[10];
		
		for(int i = 12; i < argList.length; i++) {
			resourceList.add(argList[i].split(":")[1]);
		}
	}
	
	public List<String> getResources() {
		return List.copyOf(resourceList);
	}

	@Override
	public int x() {
		return x;
	}

	@Override
	public int y() {
		return y;
	}

	public void drawCard(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);

		// drawing the card
		graphics2D.setColor(Card.CARD_MAIN_COLOR);
		graphics2D.fillRoundRect(x, y, CARD_WIDTH, CARD_HEIGHT, 20, 20);
		graphics2D.setColor(Color.BLACK);
		graphics2D.drawRoundRect(x, y, CARD_WIDTH, CARD_HEIGHT, 20, 20);
		
		drawCardCorners(graphics2D);
		drawResources(graphics2D);
	}
	
	private void drawResources(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		// variables for the drawing of the resources in the middle
		var size = (int) (Card.RESOURCE_SIZE*0.8);
		var ySpacing = (Card.CARD_HEIGHT - size*resourceList.size())/(resourceList.size()+1);
		var xRes = x + Card.CARD_WIDTH / 2 - size / 2;
		var yRes = y + ySpacing;
		// drawing each resources
		for(int i = 0; i < resourceList.size(); i++) {
			graphics2D.setColor(Card.getColor(resourceList.get(i)));
			graphics2D.fillRoundRect(xRes, yRes, size, size, 20, 20);
			yRes += size + ySpacing;
		}
	}

	private void drawCardCorners(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		// drawing the corners based on if the card is reversed or not
		if(isReversed) {
			drawCardCorner(reverseTopLeftCorner, graphics2D, x, y, CORNER_SIZE, CORNER_SIZE);
			drawCardCorner(reverseTopRightCorner, graphics2D, x + CARD_WIDTH - CORNER_SIZE, y, CORNER_SIZE, CORNER_SIZE);
			drawCardCorner(reverseBottomLeftCorner, graphics2D, x, y + CARD_HEIGHT - CORNER_SIZE, CORNER_SIZE, CORNER_SIZE);
			drawCardCorner(reverseBottomRightCorner, graphics2D, x + CARD_WIDTH - CORNER_SIZE, y + CARD_HEIGHT - CORNER_SIZE, CORNER_SIZE, CORNER_SIZE);
			return;
		}
		drawCardCorner(topLeftCorner, graphics2D, x, y, CORNER_SIZE, CORNER_SIZE);
		drawCardCorner(topRightCorner, graphics2D, x + CARD_WIDTH - CORNER_SIZE, y, CORNER_SIZE, CORNER_SIZE);
		drawCardCorner(bottomLeftCorner, graphics2D, x, y + CARD_HEIGHT - CORNER_SIZE, CORNER_SIZE, CORNER_SIZE);
		drawCardCorner(bottomRightCorner, graphics2D, x + CARD_WIDTH - CORNER_SIZE, y + CARD_HEIGHT - CORNER_SIZE, CORNER_SIZE, CORNER_SIZE);
	}
	
	private void drawCardCorner(String corner, Graphics2D graphics2D, int x, int y, int width, int height) {
		Objects.requireNonNull(corner);
		Objects.requireNonNull(graphics2D);
		// not drawing if the corner is invisible
		if(corner.equals("Invisible")) {
			return;
		}
		graphics2D.setColor(CARD_CORNER_COLOR);
		graphics2D.fillRoundRect(x, y, width, height, 20, 20);
		// stop drawing if the corner is empty
		if (corner.equals("Empty")) {
			return;
		}
		// drawing the content of the corner
		drawCardCornerContent(corner, graphics2D, x, y);
	}
	
	private void drawCardCornerContent(String corner, Graphics2D graphics2D, int x, int y) {
		Objects.requireNonNull(corner);
		Objects.requireNonNull(graphics2D);
		// drawing the content of the corner
		var dividedCorner = corner.split(":");
		if(String.valueOf(dividedCorner[0]).equals("A")) {
			// drawing the letter if there is an artifact
			int contentX = (int) (x + CORNER_SIZE*0.3);
			int contentY = (int) (y + CORNER_SIZE*0.8);
			graphics2D.setColor(CARD_CORNER_TEXT_COLOR);
			graphics2D.drawString(String.valueOf(dividedCorner[1].charAt(0)), contentX, contentY);
		} else {
			// drawing a colored rectangle if it is a resource
			var resourceColor = Card.getColor(String.valueOf(dividedCorner[1]));
			int resX = x + (CORNER_SIZE - RESOURCE_SIZE)/2;
			int resY = y + (CORNER_SIZE - RESOURCE_SIZE)/2;
			graphics2D.setColor(resourceColor);
			graphics2D.fillRoundRect(resX, resY, RESOURCE_SIZE, RESOURCE_SIZE, 20, 20);
			}
	}

	@Override
	public boolean isPosInCard(Location mousePos) {
		Objects.requireNonNull(mousePos);
		// return true if the position of the mouse is inside the card
		return x < mousePos.x() && mousePos.x() <  x + CARD_WIDTH
				&& y < mousePos.y() && mousePos.y() < y + CARD_HEIGHT;
	}

	@Override
	public void setPos(int newX, int newY) {
		x = newX;
		y = newY;
	}

	@Override
	public void setPos(double newX, double newY) {
		x = (int) newX;
		y = (int) newY;
	}

	@Override
	public void replace(int replaceType, Card replaceCard) {
		return;
	}

	@Override
	public void score(Player player, int cornersCovered) {
		return;
	}

	@Override
	public void setReverse(boolean value) {
		isReversed = value;
	}

	@Override
	public List<Corner> getAllCorners() {
		// returns a list of all corners, based on if the card is reversed or not
		if(isReversed) {
			return List.of(new Corner(x, y, reverseTopLeftCorner), new Corner(x + CARD_WIDTH - CORNER_SIZE, y, reverseTopRightCorner), 
					new Corner(x, y + CARD_HEIGHT - CORNER_SIZE, reverseBottomLeftCorner), new Corner(x + CARD_WIDTH - CORNER_SIZE, y + CARD_HEIGHT - CORNER_SIZE, reverseBottomRightCorner));
		}
		return List.of(new Corner(x, y, topLeftCorner), new Corner(x + CARD_WIDTH - CORNER_SIZE, y, topRightCorner), 
				new Corner(x, y + CARD_HEIGHT - CORNER_SIZE, bottomLeftCorner), new Corner(x + CARD_WIDTH - CORNER_SIZE, y + CARD_HEIGHT - CORNER_SIZE, bottomRightCorner));
	}

	@Override
	public boolean isReversed() {
		return isReversed;
	}

	@Override
	public String getKingdom() {
		return "";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(topLeftCorner, topRightCorner, bottomLeftCorner, bottomRightCorner, 
				reverseTopLeftCorner, reverseTopRightCorner, reverseBottomLeftCorner, reverseBottomRightCorner, resourceList);
	}
	
	@Override
	public boolean equals(Object o) {
		return o instanceof StarterCard other
				&& topLeftCorner.equals(other.topLeftCorner) && topRightCorner.equals(other.topRightCorner) && bottomLeftCorner.equals(other.bottomLeftCorner)
				&& bottomRightCorner.equals(other.bottomRightCorner) && reverseTopLeftCorner.equals(other.reverseTopLeftCorner) && reverseTopRightCorner.equals(other.reverseTopRightCorner) 
				&& reverseBottomLeftCorner.equals(other.reverseBottomLeftCorner) && reverseBottomRightCorner.equals(other.reverseBottomRightCorner)
				&& resourceList.equals(other.resourceList);
	}

}
