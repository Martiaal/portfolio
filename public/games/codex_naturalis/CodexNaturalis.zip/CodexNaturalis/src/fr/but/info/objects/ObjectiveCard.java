package fr.but.info.objects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.github.forax.zen.PointerEvent.Location;

public class ObjectiveCard implements Card {
	
	public record MiniCard(String kingdom, int x, int y) {
		public MiniCard {
			Objects.requireNonNull(kingdom);
		}
		
		public void drawMiniCard(Graphics2D graphics2D, int xOffset, int yOffset) {
			graphics2D.setColor(Card.getColor(kingdom));
			graphics2D.fillRect(xOffset + x, yOffset + y, MINI_WIDTH, MINI_HEIGHT);
			graphics2D.setColor(Color.BLACK);
			graphics2D.drawRect(xOffset + x, yOffset + y, MINI_WIDTH, MINI_HEIGHT);
		}
	}
	
	private final String type;
	private final int scoring;
	
	private final List<String> infoList = new ArrayList<String>();
	private final List<MiniCard> miniCards = new ArrayList<MiniCard>();
	private final Map<String, Integer> artiMap = new HashMap<String, Integer>();
	
	private int x = -CARD_WIDTH;
	private int y = -CARD_HEIGHT;
	private int xOffset = 0;
	private int yOffset = 0;
	private int miniFrameWidth = 0;
	private int miniFrameHeight = 0;
	
	public ObjectiveCard(String[] argList) {
		type = argList[1];
		// infoList is the list of required things to score points
		for(int i = 2; !argList[i].equals("Scoring"); i++) {
			infoList.add(argList[i]);
			if(type.equals("Artifact")) {
				artiMap.put(argList[i], artiMap.getOrDefault(argList[i], 0) + 1);
			}
		}
		scoring = Integer.valueOf(argList[argList.length-1].split(":")[1]);
		
		if(type.equals("Pattern")) {
			setMiniCards();
		}
	}

	private void setMiniCards() {
		// initializing the positioning of every mini cards from objective cards with pattern
		int x = 0;
		int y = 0;
		int xMin = 0;
		int xMax = 0;
		int yMin = 0;
		int yMax = 0;
		for(int i = 0; i < infoList.size(); i++) {
			// for pattern objectives, infoList is in the form [kingdom, position, kingdom, position, kingdom, ... ]
			// this is why we add mini card only when i%2 = 0
			if(i % 2 == 0) {
				miniCards.add(new MiniCard(infoList.get(i), x, y));
				// updating xMin, yMin, xMax and yMax
				// these variables will be useful later to draw the mini cards
				if(x < xMin) xMin = x;
				if(x + MINI_WIDTH > xMax) xMax = x + MINI_WIDTH;
				if(y < yMin) yMin = y;
				if(y + MINI_HEIGHT > yMax) yMax = y + MINI_HEIGHT;
				continue;
			}
			// updating the new position based on the position from infoList
			switch(infoList.get(i) ) {
			case "Top" : y += MINI_CORNER*2 - MINI_HEIGHT*2; break;
			case "Bottom" : y += MINI_HEIGHT*2 - MINI_CORNER*2; break;
			case "TopLeft" : y += MINI_CORNER - MINI_HEIGHT; x += MINI_CORNER - MINI_WIDTH; break;
			case "TopRight" : y += MINI_CORNER - MINI_HEIGHT; x += MINI_WIDTH - MINI_CORNER; break;
			case "BottomRight" : y += MINI_HEIGHT - MINI_CORNER; x += MINI_WIDTH - MINI_CORNER; break;
			case "BottomLeft" : y += MINI_HEIGHT - MINI_CORNER; x += MINI_CORNER - MINI_WIDTH; break;
			}
		}
		// offsets will be values to add when drawing, as with positions as TopLeft, we move backwards in the coordinates
		xOffset = xMin*-1;
		yOffset = yMin*-1;
		// width and height will allow to draw patterns in the middle of the card
		miniFrameWidth = xMax - xMin;
		miniFrameHeight = yMax - yMin;
	}

	@Override
	public int x() {
		return x;
	}

	@Override
	public int y() {
		return y;
	}

	@Override
	public void drawCard(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);

		// drawing the card
		graphics2D.setColor(Card.CARD_MAIN_COLOR);
		graphics2D.fillRoundRect(x, y, CARD_WIDTH, CARD_HEIGHT, 20, 20);
		graphics2D.setColor(Color.BLACK);
		graphics2D.drawRoundRect(x, y, CARD_WIDTH, CARD_HEIGHT, 20, 20);
		
		Card.drawRectInfo(String.valueOf(scoring), graphics2D, x + Card.CARD_WIDTH/2 - Card.POINT_ZONE_SIZE/2, y);
		
		// drawing what will make the player score points
		if(type.equals("Pattern")) {
			drawMiniCards(graphics2D);
			return;
		}
		if(type.equals("Resource")) {
			drawResources(graphics2D);
			return;
		}
		
		drawArtifacts(graphics2D);
	}

	private void drawArtifacts(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		
		graphics2D.setColor(Color.BLACK);
		// variables useful for the positioning of every artifacts
		var size = (int) (RESOURCE_SIZE*1);
		var xSpacing = (CARD_WIDTH - size*infoList.size())/(infoList.size()+1);
		var xRes = x + xSpacing;
		var yRes = y + POINT_ZONE_SIZE + (CARD_HEIGHT - POINT_ZONE_SIZE)/2 - size/2;
		// drawing each artifacts
		for(int i = 0; i < infoList.size(); i++) {
			graphics2D.drawString(String.valueOf(infoList.get(i).charAt(0)), xRes, yRes);
			xRes += size + xSpacing;
		}
	}

	private void drawMiniCards(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		
		int xFrame = CARD_WIDTH/2 - miniFrameWidth/2;
		int yFrame = (CARD_HEIGHT + POINT_ZONE_SIZE)/2 - miniFrameHeight/2;
		// drawing each mini cards
		for(var miniCard : miniCards) {
			miniCard.drawMiniCard(graphics2D, xOffset + x + xFrame, yOffset + y + yFrame);
		}
	}

	private void drawResources(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		// variables useful for the positioning of every resources
		var size = (int) (RESOURCE_SIZE*1);
		var xSpacing = (CARD_WIDTH - size*infoList.size())/(infoList.size()+1);
		var xRes = x + xSpacing;
		var yRes = y + POINT_ZONE_SIZE + (CARD_HEIGHT - POINT_ZONE_SIZE)/2 - size/2;
		// drawing each resources
		for(int i = 0; i < infoList.size(); i++) {
			graphics2D.setColor(Card.getColor(infoList.get(i)));
			graphics2D.fillRoundRect(xRes, yRes, size, size, 20, 20);
			xRes += size + xSpacing;
		}
	}

	@Override
	public boolean isPosInCard(Location mousePos) {
		Objects.requireNonNull(mousePos);
		// return true if the position of the mouse is inside the card
		return x < mousePos.x() && mousePos.x() <  x + CARD_WIDTH
				&& y < mousePos.y() && mousePos.y() < y + CARD_HEIGHT;
	}

	@Override
	public void setPos(int newX, int newY) {
		x = newX;
		y = newY;
	}

	@Override
	public void setPos(double newX, double newY) {
		x = (int) newX;
		y = (int) newY;
	}

	@Override
	public void replace(int replaceType, Card replaceCard) {
		return;
	}

	@Override
	public void score(Player player, int cornersCovered) {
		Objects.requireNonNull(player);
		// scoring, based on the type of scoring of the card
		switch(type) {
		case "Resource" : resourceScore(player); break;
		case "Artifact" : artifactScore(player); break;
		case "Pattern" : patternScore(player); break;
		}
	}

	private void patternScore(Player player) {
		Objects.requireNonNull(player);
		int amount = 0;
		for(var card : player.getPlayedCards()) {
			// for every recognized patterns, we increase the amount of points which the player will score
			if(checkPattern(card, player.getPlayedCards())) {
				amount += scoring;
			}
		}
		System.out.println(amount);
		player.addScore(amount);
	}

	private boolean checkPattern(Card card, List<Card> playedCards) {
		Objects.requireNonNull(card);
		Objects.requireNonNull(playedCards);
		// returning false if the first card checked is not of the good kingdom
		if(! card.getKingdom().equals(infoList.getFirst())) {
			return false;
		}
		// xOther and yOther will be the coordinates to check the card on
		int xOther = card.x() + CARD_WIDTH/2;
		int yOther = card.y() + CARD_HEIGHT/2;
		for(int i = 1; i < infoList.size(); i++) {
			// for pattern objectives, infoList is in the form [kingdom, position, kingdom, position, kingdom, ... ]
			// this is why we check card's kingdom only when i%2 = 0
			if(i % 2 == 0) {
				card = getPlayedCardAtPos(playedCards, xOther, yOther);
				// if there is no card at the given position, then there is no pattern
				if(card == null) {
					return false;
				}
				// if the kingdom is wrong, then there is no pattern
				if(! card.getKingdom().equals(infoList.get(i))) {
					return false;
				}
				continue;
			}
			// updating the new position based on the position from infoList
			switch(infoList.get(i) ) {
			case "Top" : yOther += CORNER_SIZE*2 - CARD_HEIGHT*2; break;
			case "Bottom" : yOther += CARD_HEIGHT*2 - CORNER_SIZE*2; break;
			case "TopLeft" : yOther += CORNER_SIZE - CARD_HEIGHT; xOther += CORNER_SIZE - CARD_WIDTH; break;
			case "TopRight" : yOther += CORNER_SIZE - CARD_HEIGHT; xOther += CARD_WIDTH - CORNER_SIZE; break;
			case "BottomRight" : yOther += CARD_HEIGHT - CORNER_SIZE; xOther += CARD_WIDTH - CORNER_SIZE; break;
			case "BottomLeft" : yOther += CARD_HEIGHT - CORNER_SIZE; xOther += CORNER_SIZE - CARD_WIDTH; break;
			}
		}
		return true;
	}

	private Card getPlayedCardAtPos(List<Card> playedCards, int x, int y) {
		Objects.requireNonNull(playedCards);
		// return the card at coordinates (x, y) if there is one, else null
		for(int i = 0; i < playedCards.size(); i++) {
			if(playedCards.get(i).isPosInCard(new Location(x, y))) {
				return playedCards.get(i);
			}
		}
		return null;
	}

	private void artifactScore(Player player) {
		Objects.requireNonNull(player);
		int minimum = -1;
		// for each artifacts required, we divide the number of artifacts the player has by the number of artifacts required
		// then we add the one we have the less to score, as it is this one that will be determinant
		for(var artifact : artiMap.keySet()) {
			int amount = (int) (player.getResource(String.valueOf(artifact.charAt(0))) / artiMap.get(artifact));
			if(minimum == -1 || minimum > amount) minimum = amount;
		}
		player.addScore(minimum*scoring);
	}

	private void resourceScore(Player player) {
		Objects.requireNonNull(player);
		// we divide the number of resources the player has by the number of resources required
		int amount = (int) (player.getResource(infoList.getFirst()) / infoList.size());
		player.addScore(amount*scoring);
	}

	@Override
	public void setReverse(boolean value) {
		return;
	}

	@Override
	public List<Corner> getAllCorners() {
		return null;
	}

	@Override
	public boolean isReversed() {
		return false;
	}

	@Override
	public String getKingdom() {
		return "";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(type, scoring, infoList);
	}
	
	@Override
	public boolean equals(Object o) {
		return o instanceof ObjectiveCard other
				&& type.equals(other.type) && scoring == other.scoring && infoList.equals(other.infoList);
	}

}
