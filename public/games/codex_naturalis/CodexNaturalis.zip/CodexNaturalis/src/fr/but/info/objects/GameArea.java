package fr.but.info.objects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Map;
import java.util.Objects;

public class GameArea {
	private final String label;
	private final int width;
	private final int height;
	private final int x;
	private final int y;
	
	private final Color borderColor = new Color(255, 255, 255);
	
	public GameArea(String label, int x, int y, int width, int height) {
		Objects.requireNonNull(label);
		this.label = label;
		this.width = width;
		this.height = height;
		this.x = x;
		this.y = y;
	}
	
	public void drawGameArea(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		// drawing a game area
		graphics2D.setColor(borderColor);
		graphics2D.drawRoundRect(x, y, width, height, 30, 30);
		graphics2D.drawString(label, x, y - 10);
	}

	public static void addGameArea(Map<String, GameArea> areasList, String line, int screenWidth, int screenHeight) {
		Objects.requireNonNull(areasList);
		Objects.requireNonNull(line);
		var argList = line.split(" ");
		var areaLabel = argList[1];
		areaLabel.replace('_', ' ');
		// converting position values from percentages to pixels
		int areaX = (int) screenWidth * Integer.valueOf(argList[2])/100;
		int areaWidth = (int) screenWidth * Integer.valueOf(argList[3])/100;
		int areaY = (int) screenHeight * Integer.valueOf(argList[4])/100;
		int areaHeight = (int) screenHeight * Integer.valueOf(argList[5])/100;
		// adding the area to the areasList
		areasList.put(argList[0], new GameArea(areaLabel, areaX, areaY, areaWidth, areaHeight));
	}
	
	public int x() {
		return x;
	}
	
	public int y() {
		return y;
	}
	
	public int width() {
		return width;
	}
	
	public int height() {
		return height;
	}
	
	
}
