package fr.but.info.game;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.github.forax.zen.ApplicationContext;

import fr.but.info.objects.Button;
import fr.but.info.objects.Card;
import fr.but.info.objects.GameArea;
import fr.but.info.objects.Player;

public class ScreenManager {
	
	private final ApplicationContext context;
	private final GameManager gameManager;
	private int fontSize = 0;
	private final List<Button> menuButtons = new ArrayList<Button>();
	
	public ScreenManager(ApplicationContext context, GameManager gameManager) {
		Objects.requireNonNull(context);
		Objects.requireNonNull(gameManager);
		this.context = context;
		this.gameManager = gameManager;
	}
	
	public void getContext() throws IOException {
		var screenInfo = context.getScreenInfo();
		var width = screenInfo.width();
		var height = screenInfo.height();
		
		// getting informations relative to different game areas
		gameManager.retrieveAllGameAreas(width, height);
		
		// setting the font size, depending on the width of the screen
		setFontSize(width);
		
		// getting all menu's buttons
		createMenuButtons(width, height);
		
		// creating a event manager
		var eventManager = new EventManager(context, gameManager, this);
		
		for(;;) {
			eventManager.getEventContext();
			
			context.renderFrame(graphics2D -> {
				getGraphicsContext(graphics2D, width, height);
			});
		}
	}
	
	private void createMenuButtons(int width, int height) {
		// labels corresponding to each amount of players
		var labels = List.of("1 player", "2 players", "3 players", "4 players");
		var buttonHeight = (int) (height*0.0486);
		var ySpacing = buttonHeight / 2;
		var y = height/2 - ((buttonHeight + ySpacing)*labels.size())/2;
		// creating a button for each amount of players
		for(var label : labels) {
			// adjusting the button width to the length of the label
			var buttonWidth = label.length()*16;
			menuButtons.add(new Button(label, width/2 - buttonWidth/2, y, buttonWidth, buttonHeight));
			y += ySpacing + buttonHeight;
		}
	}
	
	public List<Button> getMenuButtons() {
		return List.copyOf(menuButtons);
	}

	private void setFontSize(int width) {
		// adjusting the font size to the width of the screen
		fontSize = (int) (width*0.02);
	}

	private void getGraphicsContext(Graphics2D graphics2D, int width, int height) {
		Objects.requireNonNull(graphics2D);
		// clearing the window
		graphics2D.clearRect(0, 0, width, height);
		
		// drawing the window depending on which state of the application we are (playing, ending...)
		switch(gameManager.getGameState()) {
		case "menu" : menuDrawings(graphics2D, width, height); break;
		case "play" : gameDrawings(graphics2D, width, height); break;
		case "win" : winDrawings(graphics2D, width, height); break;
		case "starter" : starterChoiceDrawings(graphics2D, width, height); break;
		case "objective" : objectiveChoiceDrawings(graphics2D, width, height); break;
		}
	}
	
	private void objectiveChoiceDrawings(Graphics2D graphics2D, int width, int height) {
		Objects.requireNonNull(graphics2D);
		// setting the font
		graphics2D.setFont(new Font("Helvetica", 0, fontSize));
		// drawing the explanatory text
		graphics2D.setColor(Color.WHITE);
		var text = "Click on the objective card you desire : Player " + String.valueOf(gameManager.getObjectiveCardNum()/2 + 1);
		graphics2D.drawString(text, 10, 30);
		// getting informations relative to the placement of objective cards
		var xSpacing = (width - Card.CARD_WIDTH*2)/3;
		var x = xSpacing;
		var y = height/2 - Card.CARD_HEIGHT/2;
		// getting objective cards
		var obj1 = gameManager.getFirstObjective();
		var obj2 = gameManager.getSecondObjective();
		// setting objective cards positions and drawing them
		obj1.setPos(x, y);
		obj2.setPos(x + Card.CARD_WIDTH + xSpacing, y);
		obj1.drawCard(graphics2D);
		obj2.drawCard(graphics2D);
	}

	private void starterChoiceDrawings(Graphics2D graphics2D, int width, int height) {
		Objects.requireNonNull(graphics2D);
		// setting the font
		graphics2D.setFont(new Font("Helvetica", 0, fontSize));
		// drawing the explanatory text
		graphics2D.setColor(Color.WHITE);
		var text = "Press 'r' to get the reverse card (right), any other key to get the basic card (left) : Player " + String.valueOf(gameManager.getStarterCardNum() + 1);
		graphics2D.drawString(text, 10, 30);
		// getting informations relative to the placement of starter card
		var xSpacement = (width - Card.CARD_WIDTH*2)/3;
		var x = xSpacement;
		var y = height/2 - Card.CARD_HEIGHT/2;
		// getting the starter card
		var sc = gameManager.getStarterCard();
		// setting position and drawing the starter card's front and back
		sc.setPos(x, y);
		sc.setReverse(false);
		sc.drawCard(graphics2D);
		sc.setPos(x+xSpacement+Card.CARD_WIDTH, y);
		sc.setReverse(true);
		sc.drawCard(graphics2D);
	}

	private void winDrawings(Graphics2D graphics2D, int width, int height) {
		Objects.requireNonNull(graphics2D);
		// setting the font
		graphics2D.setFont(new Font("Helvetica", 0, fontSize));
		// getting the ranking
		var ranking = gameManager.getRanking();
		int position = 0;
		int formerScore = 0;
		int realPos = 0;
		var x = 10;
		var y = fontSize + 10;
		// drawing each ranks
		for(var player : ranking.keySet()) {
			// the real position is useful in the case where two players have the same amount of points. It allows to keep the technical position
			// while two players can have the same positions
			realPos++;
			// if the player does not have the same score as the former player, we actualize his position in the ranking
			if(formerScore != player.getScore()) {
				position = realPos;
			}
			formerScore = player.getScore();
			// drawing the player rank
			drawPlayerRank(graphics2D, player, position, x, y);
			y += fontSize + 10;
		}
		// drawing additional informations
		String roundText = "Round : " + gameManager.getRound();
		graphics2D.drawString(roundText, x, y);
		y += fontSize + 10;
		graphics2D.drawString("Press any key to come back to the menu", x, y);
	}

	private void drawPlayerRank(Graphics2D graphics2D, Player player, int position, int x, int y) {
		Objects.requireNonNull(graphics2D);
		Objects.requireNonNull(player);
		// drawing player's color in form of a square
		graphics2D.setColor(player.getColor());
		graphics2D.fillRect(x, y-fontSize, Card.RESOURCE_SIZE, Card.RESOURCE_SIZE);
		// the text is in form : player n, score : totalPoints (normalPoints + objectivePoints)
		var text = position + ". Player " + (gameManager.getPlayerIndex(player)+1) + ", score : " + player.getScore() + " ( " + player.getFormerScore() + " + " + (player.getScore()-player.getFormerScore()) + " )";
		graphics2D.setColor(Color.WHITE);
		graphics2D.drawString(text, x + 10 + Card.RESOURCE_SIZE, y);
	}

	private void menuDrawings(Graphics2D graphics2D, int width, int height) {
		Objects.requireNonNull(graphics2D);
		// setting the font
		graphics2D.setFont(new Font("Helvetica", 0, fontSize));
		// drawing each buttons
		for(var button : menuButtons) {
			button.drawButton(graphics2D);
		}
	}

	private void gameDrawings(Graphics2D graphics2D, int width, int height) {
		Objects.requireNonNull(graphics2D);
		// drawing every game's element
		// setting the font relative to card's information
		graphics2D.setFont(new Font("Helvetica", 0, Card.FONT_SIZE));
		drawPlayedCards(graphics2D);
		coverOutsidePlayArea(graphics2D, width, height);
		drawDecks(graphics2D);
		drawHand(graphics2D);
		drawObjectives(graphics2D);
		drawPoints(graphics2D);
		// setting the font relative to other informations
		graphics2D.setFont(new Font("Helvetica", 0, fontSize));
		drawPlayers(graphics2D);
		drawAllGameAreas(graphics2D);
		drawInfoText(graphics2D);
	}

	private void drawPlayers(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		// getting coordinates of the play area
		var x = gameManager.getGameAreaX("playArea");
		var y = gameManager.getGameAreaY("playArea");
		// drawing each player's section
		for(var player : gameManager.realPlayers()) {
			drawPlayer(graphics2D, player, x, y);
			y += Card.CORNER_SIZE;
		}
	}

	private void drawPlayer(Graphics2D graphics2D, Player player, int x, int y) {
		Objects.requireNonNull(graphics2D);
		Objects.requireNonNull(player);
		
		var height = Card.CORNER_SIZE;
		var width = Card.CARD_WIDTH;
		var color = Card.CARD_MAIN_COLOR;
		var textColor = Color.BLACK;
		// if the player is the one that must play, we set its text color to red
		if(gameManager.getPlayerIndex(player) == gameManager.getActualPlayerIndex()) textColor = Color.RED;
		// if the player is the one currently displayed, we set its background color to grey
		if(gameManager.getPlayerIndex(player) == gameManager.getDisplayPLayerIndex()) color = Color.LIGHT_GRAY;
		// drawing the background
		graphics2D.setColor(color);
		graphics2D.fillRect(x, y, width, height);
		// drawing the player's name
		graphics2D.setColor(Color.BLACK);
		graphics2D.setColor(textColor);
		graphics2D.drawString("Player " + (gameManager.getPlayerIndex(player)+1), x+10, y+30);
		// drawing the player's color
		graphics2D.setColor(player.getColor());
		var colorX = (int) (x + (width*0.82));
		var colorY = (int) (y + (height*0.28));
		var colorSize = (int) (Card.RESOURCE_SIZE*0.7);
		graphics2D.fillRect(colorX, colorY, colorSize, colorSize);
		graphics2D.setColor(Color.BLACK);
		// drawing borders to the background and the color
		graphics2D.drawRect(x, y, width, height);
		graphics2D.drawRect(colorX, colorY, colorSize, colorSize);
	}

	private void coverOutsidePlayArea(Graphics2D graphics2D, int width, int height) {
		Objects.requireNonNull(graphics2D);
		// cover the outside of the play area to hide played cards outside of it
		int xArea = gameManager.getGameAreaX("playArea");
		int yArea = gameManager.getGameAreaY("playArea");
		int widthArea = gameManager.getGameArea("playArea").width();
		int heightArea = gameManager.getGameArea("playArea").height();
		graphics2D.setColor(gameManager.getBgColor());
		graphics2D.fillRect(0, 0, xArea, height);
		graphics2D.fillRect(xArea, 0, width-xArea, yArea);
		graphics2D.fillRect(xArea+widthArea, yArea, width-xArea-widthArea, heightArea);
		graphics2D.fillRect(xArea, yArea+heightArea, width-xArea, height-yArea-heightArea);
	}

	private void drawInfoText(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		String content;
		// setting content, depending on if the player is holding a card or not
		if(gameManager.hasActiveCard()) {
			content = "Press 'r' to reverse the card";
		} else {
			content = "Press arrows to move the board";
		}
		int xContent = gameManager.getGameAreaX("playArea") + gameManager.getGameArea("playArea").width()/2;
		int yContent = gameManager.getGameAreaY("playArea") - 10;
		// drawing the information
		graphics2D.setColor(Color.WHITE);
		graphics2D.drawString(content, xContent, yContent);
	}

	private void drawPoints(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		GameArea pointsArea = gameManager.getGameArea("pointsArea");
		// drawing the points of the game inside the points area
		// getting various information relative to the placement of points square
		var height = pointsArea.height();
		var width = pointsArea.width();
		var size = Card.CORNER_SIZE;
		int xSpacing = (width-size*5)/6;
		int ySpacing = (height-size*6)/7;
		var x = pointsArea.x() + xSpacing;
		var y = pointsArea.y() - ySpacing + height - size;
		boolean leftToRight = true;
		for(int i = 1; i < 31; i++) {
			// drawing the square which will contain the point's value
			graphics2D.setColor(Card.CARD_MAIN_COLOR);
			graphics2D.fillRect(x, y, size, size);
			graphics2D.setColor(Color.BLACK);
			graphics2D.drawRect(x, y, size, size);
			// drawing the point's value
			int xNum = (int) (x + size*0.25);
			int yNum = (int) (y + size*0.75);
			graphics2D.drawString(String.valueOf(i-1), xNum, yNum);
			graphics2D.setColor(Color.WHITE);
			// not drawing a connecting line if it is the last case
			if(i == 30) continue;
			// when we reached the end of line (5 items has been drawn), we draw a vertical line, we update the y value and we inverse the 
			// leftToRight value, to go in the opposite direction
			if(i % 5 == 0 && i > 0) {
				graphics2D.drawLine(x + size/2, y, x + size/2, y - ySpacing);
				drawMiniPlayers(graphics2D, x, y, i-1);
				leftToRight = !leftToRight;
				y -= size + ySpacing;
				continue;
			}
			// drawing a horizontal line and the color of players with as many points as the value of the currently drawn point's item. 
			// positioning of the line will depend on if we go from left to right or the reverse
			if(leftToRight) {
				graphics2D.drawLine(x + size, y + (size/2), x+size+xSpacing, y + (size/2));
				drawMiniPlayers(graphics2D, x, y, i-1);
				x += size + xSpacing;
			} else {
				graphics2D.drawLine(x, y + (size/2), x-xSpacing, y + (size/2));
				drawMiniPlayers(graphics2D, x, y, i-1);
				x -= size + xSpacing;
			}
		}
	}

	private void drawMiniPlayers(Graphics2D graphics2D, int x, int y, int score) {
		Objects.requireNonNull(graphics2D);
		// getting players with a certain amount of score
		var players = gameManager.getPlayersWithScore(score);
		// getting various positioning informations
		var size = Card.COST_SIZE;
		var xMini = x - size/2;
		var yMini = y - size/2;
		for(var player : players) {
			// drawing the color of the player
			graphics2D.setColor(player.getColor());
			graphics2D.fillRect(xMini, yMini, size, size);
			// drawing the border of the player
			graphics2D.setColor(Color.BLACK);
			graphics2D.drawRect(xMini, yMini, size, size);
			xMini += size*1.1;
		}
	}

	private void drawPlayedCards(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		// drawing each played cards
		for(var card : gameManager.getDisplayPlayerPlayedCards()) {
			card.drawCard(graphics2D);
		}
	}

	private void drawHand(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		// draw each card from the player's hand
		for(var card : gameManager.getDisplayPlayerHand()) {
			card.drawCard(graphics2D);
		}
	}

	private void drawDecks(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		// drawing the three first cards of each deck
		var combinedDeck = new ArrayList<Card>();
		combinedDeck.addAll(gameManager.getResourceDeck());
		combinedDeck.addAll(gameManager.getGoldDeck());
		
		for(var card : combinedDeck) {
			card.drawCard(graphics2D);
		}	
	}
	
	private void drawObjectives(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		// draw player's objective card and the two objective cards relative to the game
		gameManager.getDisplayPlayer().getObjective().drawCard(graphics2D);
		gameManager.getFirstObjective().drawCard(graphics2D);
		gameManager.getSecondObjective().drawCard(graphics2D);
	}

	private void drawAllGameAreas(Graphics2D graphics2D) {
		Objects.requireNonNull(graphics2D);
		// drawing every game areas
		for(var gameArea : gameManager.getGameAreas()) {
			gameArea.drawGameArea(graphics2D);
		}
	}
}
