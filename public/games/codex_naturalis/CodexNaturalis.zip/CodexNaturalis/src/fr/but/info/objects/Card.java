package fr.but.info.objects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import com.github.forax.zen.PointerEvent.Location;

public interface Card {
	
	public record Corner(int x, int y, String content) {
		public Corner {
			Objects.requireNonNull(content);
		}
		
		public boolean collides(Corner other) {
			Objects.requireNonNull(other);
			boolean collisionX = x < other.x() + CORNER_SIZE && x + CORNER_SIZE > other.x();
			boolean collisionY = y < other.y() + CORNER_SIZE && y + CORNER_SIZE > other.y();
			return collisionX && collisionY;
		}
	}
	
	// each card size information
	static final int CARD_WIDTH = 150;
	static final int CARD_HEIGHT = 90;
	static final int CORNER_SIZE = (int) Math.round(CARD_WIDTH - CARD_WIDTH*0.75);
	static final int RESOURCE_SIZE = (int) Math.round(CORNER_SIZE - CORNER_SIZE*0.3);
	static final int COST_SIZE = (int) Math.round(RESOURCE_SIZE - RESOURCE_SIZE*0.6);
	static final int COST_ZONE_WIDTH = (int) Math.round((CARD_WIDTH - CORNER_SIZE*2)*0.8);
	static final int COST_ZONE_HEIGHT = (int) Math.round(COST_SIZE*1.3);
	static final int COST_ZONE_OFFSET = (CARD_WIDTH - COST_ZONE_WIDTH - CORNER_SIZE*2)/2;
	static final int COST_RES_Y = CARD_HEIGHT - (COST_ZONE_HEIGHT + COST_SIZE)/2;
	static final int POINT_ZONE_SIZE = (int) Math.round(CORNER_SIZE*0.7);
	static final int FONT_SIZE = (int) (CARD_WIDTH*0.176);
	static final double miniCoef = 0.2;
	static final int MINI_WIDTH = (int) (CARD_WIDTH*miniCoef);
	static final int MINI_HEIGHT = (int) (CARD_HEIGHT*miniCoef);
	static final int MINI_CORNER = (int) (CORNER_SIZE*miniCoef);
	// each card color information
	static final Color CARD_MAIN_COLOR = new Color(242, 217, 148);
	static final Color CARD_BORDER_COLOR = new Color(220, 147, 37);
	static final Color CARD_CORNER_COLOR = new Color(249, 246, 224);
	static final Color CARD_CORNER_TEXT_COLOR = new Color(0, 0, 0);
	static final Color FUNGI_COLOR = new Color(216, 25, 25);
	static final Color INSECT_COLOR = new Color(179, 60, 188);
	static final Color ANIMAL_COLOR = new Color(53, 216, 245);
	static final Color PLANT_COLOR = new Color(40, 181, 40);
	
	int x();
	int y();
	
	void drawCard(Graphics2D graphics2D);
	boolean isPosInCard(Location mousePos);
	void setPos(int newX, int newY);
	void setPos(double newX, double newY);
	void replace(int replaceType, Card replaceCard);
	void score(Player player, int cornersCovered);
	void setReverse(boolean value);
	List<Corner> getAllCorners();
	boolean isReversed();
	String getKingdom();
	
	static void convertStringToCard(String line, List<ResourceCard> resourceDeck, List<GoldCard> goldDeck, List<StarterCard> starterDeck, List<ObjectiveCard> objectiveDeck) {
		Objects.requireNonNull(line);
		Objects.requireNonNull(resourceDeck);
		Objects.requireNonNull(goldDeck);
		// converting a String (took from the "deck.txt" file) to a Card
		var argList = line.split(" ");
		switch(argList[0]) {
			case "ResourceCard" : resourceDeck.add(new ResourceCard(argList)); break;
			case "GoldCard" : goldDeck.add(new GoldCard(argList)); break;
			case "StarterCard" : starterDeck.add(new StarterCard(argList)); break;
			case "Objective" : objectiveDeck.add(new ObjectiveCard(argList)); break;
			default : break;
			}
			
		}
	
	public static Color getColor(String kingdom) {
		Objects.requireNonNull(kingdom);
		// returns a color depending on the kingdom
		switch(kingdom) {
		case "Plant" : return PLANT_COLOR;
		case "Fungi" : return FUNGI_COLOR;
		case "Insect" : return INSECT_COLOR;
		case "Animal" : return ANIMAL_COLOR;
		default : System.out.println(kingdom); return CARD_MAIN_COLOR;
		}
	}
	
	static void tryAddResource(HashMap<String, Integer> resMap, Corner corner) {
		Objects.requireNonNull(resMap);
		Objects.requireNonNull(corner);
		// adding the resource or the artifact to a map
		var contents = corner.content().split(":");
		if(String.valueOf(contents[0]).equals("R")) {
			resMap.put(String.valueOf(contents[1]), resMap.getOrDefault(String.valueOf(contents[1]), 0) + 1);
			return;
		}
		if(String.valueOf(contents[0]).equals("A")) {
			resMap.put(String.valueOf(contents[1].charAt(0)), resMap.getOrDefault(String.valueOf(contents[1].charAt(0)), 0) + 1);
		}
	}
	
	static void drawRectInfo(String info, Graphics2D graphics2D, int contentX, int contentY) {
		Objects.requireNonNull(info);
		Objects.requireNonNull(graphics2D);
		// draw a rectangle with an information inside
		graphics2D.setColor(Color.BLACK);
		graphics2D.drawRect(contentX, contentY, POINT_ZONE_SIZE, POINT_ZONE_SIZE);
		contentX = (int) (contentX + CORNER_SIZE*0.2);
		contentY = (int) (contentY + CORNER_SIZE*0.6);
		graphics2D.drawString(info, contentX, contentY);
	}
}
