package fr.but.info.main;

import java.io.IOException;

import fr.but.info.game.GameManager;

public class Main {
  public static void main(String[] args) throws IOException {
	  // launching the application
	  var gameManager = new GameManager();
	  gameManager.launch();
  }
}
