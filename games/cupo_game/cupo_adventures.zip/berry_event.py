import pygame as pg
from berry import Berry, Artifact


class BerryEvent:
    def __init__(self, game):
        self.game = game
        self.percent = 0
        self.percent_speed = 5
        self.all_berries = pg.sprite.Group()
        self.fall_mode = False

    def add_percent(self):
        if self.percent < 100:
            self.percent += self.percent_speed/100
        else:
            self.percent = 100

    def attempt_fall(self, screen):
        if len(self.game.all_monsters) == 0:
            if self.game.wave % 4 == 0:
                self.all_berries.add(Artifact(screen, self))
            if self.game.berries_to_add > 0:
                self.berry_fall(screen)
                self.fall_mode = True
            else:
                self.game.spawn_monster()
                self.reset_percent()

    def berry_fall(self, screen):
        if self.game.block_berry:
            self.game.block_berry = False
        else:
            for i in range(self.game.berries_to_add):
                self.all_berries.add(Berry(screen, self))
        self.game.berries_to_add = 0

    def is_full_loaded(self):
        return self.percent >= 100

    def reset_percent(self):
        self.percent = 0

    def update_bar(self, surface: pg.Surface):

        self.add_percent()

        pg.draw.rect(surface, (0, 0, 0), [10, surface.get_height() - 20, surface.get_width() - 20, 10])
        pg.draw.rect(surface, (187, 11, 11), [10, surface.get_height() - 20,
                                              ((surface.get_width()-20)/100)*self.percent, 10])
