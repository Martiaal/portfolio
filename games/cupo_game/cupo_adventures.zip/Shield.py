import pygame as pg


class Shield(pg.sprite.Sprite):
    def __init__(self, rockwell):
        super().__init__()
        self.rockwell = rockwell
        self.image = pg.image.load("assets/shield.png")
        self.health = 25
        self.rect = self.image.get_rect()
        self.rect.x = rockwell.rect.x - self.image.get_width() - 10
        self.rect.y = self.rockwell.game.screen.get_height() / 2 - self.image.get_height() / 2

    def damage(self, amount):
        if self.health == 23:
            self.image = pg.image.load("assets/shield1.png")
        elif self.health == 15:
            self.image = pg.image.load("assets/shield2.png")
        elif self.health == 5:
            self.image = pg.image.load("assets/shield3.png")
        self.health -= amount
        if self.health <= 0:
            self.remove()

    def remove(self):
        self.rockwell.game.all_shields.remove(self)
        self.rockwell.shield_phase = False
        if self.rockwell.phase != 3:
            self.rockwell.game.all_rocks = pg.sprite.Group()
