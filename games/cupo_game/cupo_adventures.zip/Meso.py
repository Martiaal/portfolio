from Narcoberry import Narcoberry
import pygame as pg


class Meso(pg.sprite.Sprite):
    def __init__(self, game):
        super().__init__()
        self.game = game
        self.all_narcoberries = pg.sprite.Group()
        self.attack = 1
        self.health = 100
        self.image = pg.image.load("assets/Meso.png")
        self.max_health = 100
        self.rect = self.image.get_rect()
        self.rect.x = 400
        self.rect.y = 500
        self.velocity = 10

    def damage(self, amount):
        if self.health - amount > amount:
            self.health -= amount
        else:
            self.game.game_over()

    def heal(self, amount):
        if self.health < self.max_health:
            self.health += amount
        if self.health > self.max_health:
            self.health = self.max_health

    def launch_narcoberry(self):
        self.all_narcoberries.add(Narcoberry(self))

    def move_back(self):
        self.rect.y += self.velocity

    def move_forward(self):
        self.rect.y -= self.velocity

    def move_left(self):
        self.rect.x -= self.velocity

    def move_right(self):
        if not self.game.check_collision(self, self.game.all_monsters):
            self.rect.x += self.velocity

    def update_health_bar(self, surface):
        pg.draw.rect(surface, (60, 63, 60), [self.rect.x + 8, self.rect.y - 22, self.image.get_width()/1.5 + 4, 9])
        pg.draw.rect(surface, (111, 210, 46), [self.rect.x + 10, self.rect.y - 20,
                                               self.health*(self.image.get_width()/1.5)/self.max_health, 5])
