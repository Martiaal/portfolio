import pygame as pg
from random import randint


class Berry(pg.sprite.Sprite):
    def __init__(self, screen, berry_event):
        super().__init__()
        self.image = pg.image.load("assets/Berries.png")
        self.rect = self.image.get_rect()
        self.velocity = randint(2, 4)
        self.rect.x = randint(self.image.get_width(), screen.get_width() - self.rect.width)
        self.rect.y = -randint(0, 800)
        self.berry_event = berry_event

    def fall(self):
        self.rect.y += self.velocity
        if self.rect.y >= 720:
            self.remove()
            if len(self.berry_event.all_berries) == 0:
                self.berry_event.reset_percent()
                self.berry_event.fall_mode = False
            if isinstance(self, Artifact):
                self.berry_event.game.block_berry = True
        if self.berry_event.game.check_collision(self, self.berry_event.game.all_mesos):
            self.retrieval()

    def remove(self):
        self.berry_event.all_berries.remove(self)
        if len(self.berry_event.all_berries) == 0:
            self.berry_event.reset_percent()
            self.berry_event.game.wave += 1
            if self.berry_event.game.actual_level - 1 != self.berry_event.game.artifacts_number:
                self.berry_event.game.change_level()
            if (self.berry_event.game.artifacts_number + 1)*4 < self.berry_event.game.wave:
                self.berry_event.game.wave -= 1
            if not self.berry_event.game.boss_mode and self.berry_event.game.is_playing:
                self.berry_event.game.spawn_monster()

    def retrieval(self):
        self.berry_event.game.meso.heal(0.5)
        self.remove()
        self.berry_event.game.score += 1


class Artifact(Berry):
    def __init__(self, screen, berry_event):
        super().__init__(screen, berry_event)
        self.image = pg.image.load("assets/Artifact.png")
        self.rect.x = randint(self.image.get_width(), screen.get_width() - self.rect.width)
        self.rect.y = -randint(0, 800)
        self.velocity = 2

    def retrieval(self):
        self.berry_event.game.artifacts_number += 1
        if self.berry_event.game.artifacts_number == 4:
            self.berry_event.game.boss_mode = True
        elif self.berry_event.game.artifacts_number == 5:
            self.berry_event.game.has_win = True
            self.berry_event.game.end_game()
        self.remove()


class Rock(pg.sprite.Sprite):
    def __init__(self, rockwell):
        super().__init__()
        self.rockwell = rockwell
        self.image = pg.image.load("assets/rock.png")
        self.rect = self.image.get_rect()
        x_max = self.rockwell.game.screen.get_width() - self.rockwell.image.get_width() - self.image.get_width() - 20
        self.rect.x = randint(0, x_max)
        self.rect.y = -randint(200, 2000)
        self.attack = 5
        self.velocity = 10

    def fall(self):
        self.rect.y += self.velocity
        if self.rect.y >= self.rockwell.game.screen.get_height():
            self.respawn()
        if self.rockwell.game.check_collision(self, self.rockwell.game.all_mesos):
            self.rockwell.game.meso.damage(self.attack)
            self.respawn()

    def respawn(self):
        self.rockwell.game.all_rocks.remove(self)
        self.rect.y = -randint(100, 2000)
        self.rect.x = randint(0, self.rockwell.game.screen.get_width() - self.rect.width - 20)
        if self.rockwell.game.check_collision(self, self.rockwell.game.all_rocks):
            self.respawn()
        else:
            self.rockwell.game.all_rocks.add(self)
