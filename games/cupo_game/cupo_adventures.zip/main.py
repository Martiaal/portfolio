import pygame as pg
import asyncio
from Game import Game


async def main():
    pg.init()
    clock = pg.time.Clock()
    FPS = 60
    # game window

    pg.display.set_caption("Les aventures de Cupo")
    width, height = 1080, 720
    screen = pg.display.set_mode((width, height))

    banner = pg.image.load("assets/banner.png")
    banner_rect = banner.get_rect()

    play_button = pg.image.load("assets/jouer.png")
    play_button_rect = play_button.get_rect()

    banner_rect.x = screen.get_width() / 2 - banner_rect.width / 2
    banner_rect.y = screen.get_height() / 2 - (banner_rect.height + play_button.get_height()) / 2 - 20

    play_button_rect.x = screen.get_width() / 2 - play_button_rect.width / 2 - 20
    play_button_rect.y = screen.get_height() / 2

    win_image1 = pg.image.load("assets/Victory.png")
    win_image2 = pg.image.load("assets/Victory2.png")


    # game variables
    game: Game = Game(screen)
    running = True

    if game.is_playing:
        game.start_game()

    # game loop
    while running:

        # images
        screen.blit(game.background, (0, 0))

        if game.is_playing:
            game.update(screen)
        elif game.has_win:
            x = screen.get_width() / 2 - win_image2.get_width() / 2
            y = screen.get_height() / 2 - win_image2.get_height() / 2
            screen.blit(win_image1, (x, y))
            y -= win_image2.get_height() - 4
            screen.blit(win_image2, (x, y))
        else:
            screen.blit(play_button, play_button_rect)
            screen.blit(banner, banner_rect)

        # update display window
        pg.display.flip()
        # events
        for event in pg.event.get():
            if event.type == pg.QUIT:
                running = False
            elif event.type == pg.KEYDOWN:
                game.pressed[event.key] = True
                if event.key == pg.K_SPACE:
                    game.meso.launch_narcoberry()
                elif event.key == pg.K_r:
                    game.berry_event.percent_speed = 50
                    game.artifacts_number = 3
                    game.actual_level = 4
                    game.wave = 16
                elif event.key == pg.K_e:
                    game.meso.health = 100
            elif event.type == pg.KEYUP:
                game.pressed[event.key] = False
            elif event.type == pg.MOUSEBUTTONDOWN:
                if game.has_win:
                    game.has_win = False
                if play_button_rect.collidepoint(event.pos):
                    game.start_game()

        clock.tick(FPS)
        await asyncio.sleep(0)

asyncio.run(main())
