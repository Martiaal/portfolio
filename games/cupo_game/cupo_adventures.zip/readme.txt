1-run on terminal : "pip install -r requirements.txt"
2-then run "python main.py"