from random import randint

import pygame as pg

from Narcoberry import Ball
from Shield import Shield
from berry import Artifact, Rock


class Monster(pg.sprite.Sprite):
    def __init__(self, game):
        super().__init__()
        self.game = game
        if isinstance(self, Rockwell):
            self.image = pg.image.load("assets/rockwell.png")
        else:
            self.image = pg.image.load(self.game.get_image("monster1"))
        self.add_berries = 1
        self.attack = 0.75
        self.health = 3
        self.max_health = 3
        self.rect = self.image.get_rect()
        self.rect.x = 1110
        self.rect.y = randint(20, self.game.screen.get_height() - self.image.get_height())
        self.remove_berries = 5
        self.velocity = self.game.base_velocities[1]

    def damage(self, amount):
        self.health -= amount
        if self.health <= 0:
            self.game.bonus_speed += 0.1
            self.game.berries_to_add += self.add_berries
            self.remove()

    def forward(self):
        if not self.game.check_collision(self, self.game.all_mesos):
            velocity_ratio = self.velocity * self.game.ref_velocity_ratio / self.game.ref_velocity
            max_velo_bonus = self.game.ref_velocity + self.game.bonus_speed
            self.rect.x -= max_velo_bonus * velocity_ratio / self.game.ref_velocity_ratio
        else:
            self.game.meso.damage(self.attack)
        if self.rect.x <= -self.image.get_width():
            self.remove()
            self.game.score -= self.remove_berries
            font = pg.font.Font(None, 50)
            self.game.removed_berry_text = font.render(f"(- {self.remove_berries}) ", True, (239, 17, 17))
            self.game.removed_berry_timer = 0
            if self.game.score < 0:
                self.game.score = 0

    def remove(self):
        self.game.all_monsters.remove(self)
        if not self.game.berry_event.is_full_loaded():
            self.game.spawn_monster()
        else:
            self.game.berry_event.attempt_fall(self.game.screen)

    def update_health_bar(self, surface):
        pg.draw.rect(surface, (60, 63, 60), [self.rect.x + 8, self.rect.y - 22, self.image.get_width()/1.5 + 4, 9])
        pg.draw.rect(surface, (111, 210, 46), [self.rect.x + 10, self.rect.y - 20,
                                               self.health*(self.image.get_width()/1.5)/self.max_health, 5])


class MiniMonster(Monster):
    def __init__(self, game):
        super().__init__(game)
        self.image = pg.image.load("assets/Troodon.png")
        self.add_berries = 0
        self.attack = 0.1
        self.health = 1
        self.max_health = 1
        self.rect = self.image.get_rect()
        self.rect.x = 1110
        self.rect.y = randint(20, self.game.screen.get_height() - self.image.get_height())
        self.remove_berries = 20
        self.velocity = self.game.base_velocities[0]


class MediumMonster(Monster):
    def __init__(self, game):
        super().__init__(game)
        self.image = pg.image.load(self.game.get_image("monster2"))
        self.add_berries = 5
        self.attack = 3
        self.health = 10
        self.max_health = 10
        self.rect = self.image.get_rect()
        self.rect.x = 1110
        self.rect.y = randint(20, self.game.screen.get_height() - self.image.get_height())
        self.remove_berries = 10
        self.velocity = self.game.base_velocities[2]


class BigMonster(Monster):
    def __init__(self, game):
        super().__init__(game)
        self.image = pg.image.load("assets/Gigano.png")
        self.add_berries = 10
        self.attack = 5
        self.health = 15
        self.max_health = 15
        self.rect = self.image.get_rect()
        self.rect.x = 1110
        self.rect.y = randint(20, self.game.screen.get_height() - self.image.get_height())
        self.remove_berries = 10
        self.velocity = self.game.base_velocities[3]


class Rockwell(Monster):
    def __init__(self, game):
        super().__init__(game)
        self.attack = 15
        self.health = 99
        self.max_health = 99
        self.phase = 1
        self.rect = self.image.get_rect()
        self.rect.x = self.game.screen.get_width() - self.image.get_width() - 10
        self.rect.y = 20
        self.shield_phase = False
        self.velocity = 5
        # ball throwing percents
        self.percent = 0
        self.percent_speed = 75

    def add_rocks(self):
        n = 10 if self.phase == 1 else 15
        for i in range(n):
            self.game.all_rocks.add(Rock(self))

    def damage(self, amount):
        if not self.shield_phase:
            self.health -= amount
        if self.health % 33 == 0 and self.health > 0:
            self.shield_phase = True
            self.game.all_shields.add(Shield(self))
            self.add_rocks()
            self.phase += 1
            self.health -= 1
        if self.health <= 0:
            self.remove()

    def forward(self):
        self.rect.y -= self.velocity
        self.percent += self.percent_speed / 100
        if self.percent >= 100:
            self.percent = 0
            self.throw_ball()
        if self.rect.y >= self.game.screen.get_height() - self.image.get_height() - 10:
            self.velocity *= -1
        elif self.rect.y <= 10:
            self.velocity *= -1

    def remove(self):
        self.game.all_monsters.remove(self)
        new_artifact = Artifact(self.game.screen, self.game.berry_event)
        new_artifact.rect.y = -new_artifact.image.get_height() - 5
        self.game.berry_event.all_berries.add(new_artifact)
        self.game.all_rocks.empty()

    def throw_ball(self):
        if not self.shield_phase:
            new_ball = Ball(self)
            self.game.meso.all_narcoberries.add(new_ball)


class UnamedEntity:
    def __init__(self):
        self.IS_WATCHING = "53 68 69 76 65 72 62 75 72 6E 20 47 61 6C 61 78 79"
        self.CALM_OR_ATTACK = "25 3643"

    def observe(self):
        """ subject 3AD7O0VV """
        pass
