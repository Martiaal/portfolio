from random import randint

from Meso import Meso
from monster import Monster, MiniMonster, MediumMonster, BigMonster, Rockwell
import pygame as pg
from berry_event import BerryEvent


class Game:
    def __init__(self, screen):
        self.is_playing = False
        self.boss_mode = False
        self.screen = screen
        self.all_monsters = pg.sprite.Group()
        self.all_mesos = pg.sprite.Group()
        self.all_rocks = pg.sprite.Group()
        self.all_shields = pg.sprite.Group()
        self.meso: Meso = Meso(self)
        self.all_mesos.add(self.meso)
        self.berry_event = BerryEvent(self)
        self.pressed = {}
        # images level
        self.all_images = {"background": ["assets/background.png", "assets/Background_ice.png", "assets/Background_swamp.png", "assets/Background_abe.png"],
                           "monster1": ["assets/Raptor.png", "assets/Smilodon.png", "assets/Kaprosuchus.png", "assets/Ravager.png"],
                           "monster2": ["assets/Rex.png", "assets/Yutyrannus.png", "assets/Spino.png", "assets/Reaper.png"]}
        self.background = pg.image.load(self.all_images["background"][0])
        # values
        self.actual_level = 1
        self.artifacts_number = 0
        self.berries_to_add = 0
        self.block_berry = False
        self.bonus_speed = 0
        self.base_velocities = [2.4, 2, 1, 0.8]
        self.has_win = False
        self.ref_velocity = 2
        self.ref_velocity_ratio = self.ref_velocity * 100 / self.base_velocities[0]
        self.removed_berry_text = None
        self.removed_berry_timer = 0
        self.score = 0
        self.wave = 1

    def change_level(self):
        self.actual_level += 1
        if self.actual_level == 5:
            self.enable_boss()
        elif self.actual_level == 6:
            self.end_game()
        else:
            self.update_background()
            self.bonus_speed = self.actual_level

    def check_collision(self, sprite, group):
        return pg.sprite.spritecollide(sprite, group, False, pg.sprite.collide_mask)

    def enable_boss(self):
        self.background = pg.image.load("assets/Background_boss.jpg")
        self.all_monsters.add(Rockwell(self))

    def end_game(self):
        self.game_over()
        self.boss_mode = False

    def game_over(self):
        self.all_monsters = pg.sprite.Group()
        self.berry_event.all_berries = pg.sprite.Group()
        self.meso.all_narcoberries = pg.sprite.Group()
        self.all_rocks = pg.sprite.Group()
        self.meso.all_shields = pg.sprite.Group()
        self.meso.health = self.meso.max_health
        self.berry_event.reset_percent()
        self.is_playing = False
        self.actual_level = 1
        self.berries_to_add = 0
        self.bonus_speed = 0
        self.score = 0
        self.wave = 1
        self.artifacts_number = 0
        self.update_background()

    def get_image(self, img_type):
        return self.all_images[img_type][self.actual_level - 1]

    def start_game(self):
        self.is_playing = True
        self.spawn_monster()
        self.meso.rect.x = 400
        self.meso.rect.y = 500

    def spawn_monster(self):
        n = randint(1, 100)
        if n <= 80:
            monster = Monster(self)
        elif n <= 92:
            monster = MediumMonster(self)
        elif n <= 96:
            monster = BigMonster(self)
        else:
            monster = MiniMonster(self)
        self.all_monsters.add(monster)

    def update(self, screen):
        # game information
        x = 20
        y = 20
        # berry image
        berry_image = pg.image.load("assets/Berries.png")
        screen.blit(berry_image, (x, y))
        x += berry_image.get_width()
        font = pg.font.Font(None, 50)
        score_text = font.render(f" : {self.score} ", True, (255, 255, 255))
        y += berry_image.get_height() // 2 - score_text.get_height() // 2
        screen.blit(score_text, (x, y))
        # removed berries text
        x += score_text.get_width()
        if self.removed_berry_text is not None:
            if self.removed_berry_timer < 100:
                self.removed_berry_timer += 0.75
                screen.blit(self.removed_berry_text, (x, y))
                x += self.removed_berry_text.get_width()
            else:
                self.removed_berry_text = None
                self.removed_berry_timer = 0
        # berries to add text
        berries_to_add_text = font.render(f"(+ {self.berries_to_add})", True, (35, 225, 14))
        screen.blit(berries_to_add_text, (x, y))
        # wave image
        wave_text = font.render(f"Vague : {self.wave}", True, (255, 255, 255))
        x = 20
        y += berry_image.get_height() + 10
        screen.blit(wave_text, (x, y))
        # artifacts image
        artifacts_image = pg.image.load("assets/Artifact.png")
        x = 20
        y += wave_text.get_height() + 10
        screen.blit(artifacts_image, (x, y))
        x += artifacts_image.get_width()
        artifacts_text = font.render(f" : {self.artifacts_number}/5", True, (255, 255, 255))
        y += artifacts_image.get_height() // 2 - artifacts_text.get_height() // 2
        screen.blit(artifacts_text, (x, y))

        # gameplay
        if not self.boss_mode:
            self.berry_event.update_bar(screen)
        screen.blit(self.meso.image, self.meso.rect)
        self.meso.update_health_bar(screen)
        for narcoberry in self.meso.all_narcoberries:
            narcoberry.move(screen)
        for monster in self.all_monsters:
            if isinstance(monster, Rockwell):
                if not monster.shield_phase:
                    monster.forward()
            else:
                monster.forward()
            monster.update_health_bar(screen)
        for berry in self.berry_event.all_berries:
            berry.fall()
        for rock in self.all_rocks:
            rock.fall()

        self.meso.all_narcoberries.draw(screen)
        self.all_rocks.draw(screen)
        self.all_shields.draw(screen)
        self.all_monsters.draw(screen)
        self.berry_event.all_berries.draw(screen)

        # player movement
        if self.pressed.get(pg.K_z) and self.meso.rect.y > 0:
            self.meso.move_forward()
        elif self.pressed.get(pg.K_s) and self.meso.rect.y + self.meso.rect.height < screen.get_height():
            self.meso.move_back()
        if self.pressed.get(pg.K_q) and self.meso.rect.x > 0:
            self.meso.move_left()
        elif self.pressed.get(pg.K_d) and self.meso.rect.x + self.meso.rect.width < screen.get_width():
            self.meso.move_right()

    def update_background(self):
        self.background = pg.image.load(self.all_images["background"][self.actual_level - 1])
