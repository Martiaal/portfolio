import pygame as pg


class Narcoberry(pg.sprite.Sprite):
    def __init__(self, meso):
        super().__init__()
        self.meso = meso
        self.velocity = 15
        self.image = pg.image.load("assets/Narco.png")
        self.rect = self.image.get_rect()
        self.rect.x = meso.rect.x + meso.rect.width + 10
        self.rect.y = meso.rect.y + meso.rect.height / 2
        self.origin_image = self.image
        self.angle = 0

    def move(self, screen):
        self.rect.x += self.velocity
        self.rotate()
        for monster in self.meso.game.check_collision(self, self.meso.game.all_monsters):
            self.remove()
            monster.damage(self.meso.attack)
        for shield in self.meso.game.check_collision(self, self.meso.game.all_shields):
            self.remove()
            shield.damage(self.meso.attack)
        if self.rect.x > screen.get_width():
            self.remove()

    def remove(self):
        self.meso.all_narcoberries.remove(self)

    def rotate(self):
        self.angle += 8
        self.image = pg.transform.rotozoom(self.origin_image, self.angle, 1)
        self.rect = self.image.get_rect(center=self.rect.center)


class Ball(pg.sprite.Sprite):
    def __init__(self, rockwell):
        super().__init__()
        self.rockwell = rockwell
        self.image = pg.image.load("assets/ball.png")
        self.rect = self.image.get_rect()
        self.rect.x = rockwell.rect.x - 10
        self.rect.y = rockwell.rect.y + rockwell.rect.height / 2 - self.image.get_height() / 2
        self.velocity = 15

    def move(self, screen):
        self.rect.x -= self.velocity
        for meso in self.rockwell.game.check_collision(self, self.rockwell.game.all_mesos):
            self.remove()
            meso.damage(self.rockwell.attack)
        if self.rect.x > screen.get_width():
            self.remove()

    def remove(self):
        self.rockwell.game.meso.all_narcoberries.remove(self)
